# -*- coding: utf-8 -*-
"""
@author: ZYW
"""
##命名规范#################################################################################################################################
#类名：AaBb
#文件名、变量名、函数名：aa_bb，其中如遇专有名词则保持专有名词大写
#_________________________________________________________________________________________________________________________________________

##import的知识：https://zhuanlan.zhihu.com/p/63143493
from utils.log import Log
from utils.dataset import Dataset
import pandas as pd
import os
import sys
import torch
from utils.others import check_config, warning

import time
###导入算法
from algs.YOLOv3.alg_YOLOv3 import Alg_YOLOv3
from algs.LeNet5.alg_LeNet5 import Alg_LeNet5


##############支持的数据集、模型和优化器#######################################################################################################
names_dataset_surported     = [ ('VOC2007',False), ('VOC2007MiniTest',False), ('MNIST',False), ('TC',False)] #支持的数据集VOC2007, VOC2007MiniTest（由VOC2007中前100张图像构成）和TC。
                                                # 其中的True和False表示数据集是否需要重新整理并更新dataset_info.txt中，以及训练集、验证集、测试集是否需要按比例随机地重新分配并更新dataset_info_train.txt、dataset_info_val.txt和dataset_info_test.txt
names_model_surported       = ['YOLOv3', 'LeNet5', 'SSDlite']  # 支持的模型列表
                                                # SSDlite：参考https://pytorch.org/vision/stable/generated/torchvision.models.detection.ssd300_vgg16.html#torchvision.models.detection.ssd300_vgg16
                                                #YOLOv3：参考github上的yolo3-pytorch-master
names_loss_f_surported      = ['default', 'BCE', 'CE']  #支持的损失函数列表
names_optimizer_surported   = ['Adam', 'PSO', 'PSO_CUDA', 'PSO_AC_CUDA']  #支持的优化器列表
#________________________________________________________________________________________________________________________________________


##############参数设置######################################################################################################################
##待实验的数据集列表、模型列表、损失函数列表、优化器列表
# 你现在只需要修改这两行的切片，就能自动切换数据集/模型，无需改其他参数
names_dataset = names_dataset_surported[2:3]         # 切VOC2007示例，切MNIST则用[2:3]
names_model = names_model_surported[1:2]             # 切YOLOv3示例，切LeNet5则用[1:2]
names_loss_f = names_loss_f_surported[0:1]
names_optimizer = names_optimizer_surported[2:3]


##参数配置
config_GF = {
    # ===================== 全局公共参数（所有数据集/模型共享，不随切换改变）=====================
    # 训练、验证、测试集的占比：所有元素之和等于1
    'dataset_ratio'                     : [0.85, 0.15, 0],
    # 加载数据集的子进程数。设置为0意味着将在主进程中加载
    'num_works'                         : 4,
    # 是否用预训练模型（可被数据集/模型专属参数覆盖）
    'pretrained'                        : False,
    # 是否使用GPU。待优化：使用哪些GPU，{'is':False,'index_GPU':[0]}
    'cuda'                              : True,
    # 是否将数据集加载到内存（True=内存加载，False=硬盘加载）（可被数据集专属参数覆盖）
    'load_to_memory'                    : True,
    # 训练时图像是否进行数据增强（可被数据集专属参数覆盖）
    'data_augmentation'                 : False,
    # 数据集是否作标准化处理(即归一化)（可被数据集专属参数覆盖）
    'dataset_normalize'                 : {'is': True, 'values': [[0.1307], [0.3081]]},
    # 输入的图像大小（可被数据集/模型专属参数覆盖）
    'input_shape'                       : (32, 32),
    ##一些路径设置（所有数据集/模型共享）#####################################################################################
    #数据集的路径
    'path_dataset'                      : os.path.join('.', 'dataset'),       #.表示当前目录
    # 预训练模型的路径
    'path_pretrained_model_weights'     : os.path.join('.', 'pretrained_model_weights'),
    # 记录训练过程的路径
    'path_logs'                         : os.path.join('.', 'logs'),
    # 训练后模型的保存路径
    'path_trained_model_weights'        : os.path.join('.', 'trained_model_weights'),

    # ===================== 数据集专属参数（按数据集名映射，切换数据集自动覆盖全局参数）=====================
    # 每个数据集只写和全局参数不同的部分，相同部分无需重复写
    'dataset_specific' : {
        'VOC2007': {
            'input_shape'          : (416, 416),
            'data_augmentation'    : True,
            'dataset_normalize'    : {'is': False, 'values': [[205.444503, 205.444503, 205.444503], [100.486751, 100.486751, 100.486751]]}
        },
        'VOC2007MiniTest': {  # 复用VOC2007的参数，可按需修改
            'input_shape'          : (416, 416),
            'data_augmentation'    : True,
            'dataset_normalize'    : {'is': False, 'values': [[205.444503, 205.444503, 205.444503], [100.486751, 100.486751, 100.486751]]}
        },
        'MNIST': {  # MNIST专属参数，和全局默认一致可留空，这里显式写方便你修改
            'input_shape'          : (32, 32),
            'data_augmentation'    : False,
            'dataset_normalize'    : {'is': True, 'values': [[0.1307], [0.3081]]}
        },
        'TC': {  # 你可根据TC数据集的需求补充专属参数
            'input_shape'          : (32, 32),
            'data_augmentation'    : False,
            'dataset_normalize'    : {'is': True, 'values': [[0.5], [0.5]]}
        }
    },

    # ===================== 模型专属参数（按模型名映射，切换模型自动覆盖全局/数据集参数）=====================
    # 优先级：模型专属 > 数据集专属 > 全局公共，按需添加即可
    'model_specific' : {
        'YOLOv3': {
            'pretrained'           : False,  # YOLOv3是否用预训练
            'input_shape'          : (416, 416)  # 强制YOLOv3的输入尺寸
        },
        'LeNet5': {
            'pretrained'           : False,  # LeNet5是否用预训练
            'input_shape'          : (32, 32)  # 强制LeNet5的输入尺寸
        },
        'SSDlite': {
            'pretrained'           : True,   # SSDlite可开启预训练
            'input_shape'          : (300, 300)  # SSDlite标准输入尺寸
        }
    }
    # __________________________________________________________________________________________________
}
#________________________________________________________________________________________________________________________________________
#下面第二句代码已被Z修改
if config_GF['cuda']:
    torch.cuda.set_device(0)    #固定用0号显卡

if __name__ == "__main__":

    total_start = time.time()   #总耗时!!!!!!!!!!!!!!

    #判断参数设置正误（翻译过来就是判断参数有没有设置错）
    if check_config(config_GF):
        print('参数配置错误' + warning[0])
        sys.exit()
    #清空cuda中未占用的显存。参考：https://pytorch.org/docs/stable/generated/torch.cuda.empty_cache.html?highlight=torch%20cuda%20empty_cache#torch.cuda.empty_cache
    if config_GF['cuda']:
        torch.cuda.empty_cache()

    #在所有数据集中训练所有模型
    for index_dataset in range(len(names_dataset)): #遍历所有数据集
        name_dataset = names_dataset[index_dataset][0]
        need_update = names_dataset[index_dataset][1]

        ################# 核心：自动加载数据集专属参数，覆盖全局公共参数 #################
        # 提取当前数据集的专属参数，无则返回空字典
        dataset_cfg = config_GF['dataset_specific'].get(name_dataset, {})
        # 用数据集专属参数更新全局配置（不修改原字典结构，仅临时覆盖当前循环的参数）
        config_GF.update(dataset_cfg)
        print(f'————————————自动加载{name_dataset}数据集专属参数完成————————————')

        #################准备数据集###########################################################################################################################################################################
        dataset = Dataset(config_GF, name_dataset, need_update=need_update)
        print('————————————完成%s数据集准备（是否重新整理和分配数据集：%s）' % (name_dataset, need_update))
        # ________________________________________________________________________________________________________________________________________________________________________________________________________

        for index_model in range(len(names_model)): #遍历所有模型
            name_model = names_model[index_model]

            ################# 核心：自动加载模型专属参数，覆盖全局/数据集参数 #################
            # 提取当前模型的专属参数，无则返回空字典
            model_cfg = config_GF['model_specific'].get(name_model, {})
            # 用模型专属参数更新全局配置（优先级最高，覆盖数据集参数）
            config_GF.update(model_cfg)
            print(f'————————————自动加载{name_model}模型专属参数完成————————————')

            alg = eval('Alg_' + name_model + '(is_train=True, config_GF = config_GF, dataset = dataset)')    #创建算法实例,is_train区分训练还是推理阶段
            alg.set_model()
            print('————————————完成%s网络模型构造（是否在CUDA上:%s    是否加载预训练模型:%s）' % (name_model, config_GF['cuda'], config_GF['pretrained']))

            for index_loss_f in range(len(names_loss_f)): #遍历所有损失函数
                name_loss_f = names_loss_f[index_loss_f]
                alg.set_loss_f(name_loss_f)
                print('————————————完成%s损失函数构造（是否在CUDA上:%s）' % (name_loss_f, config_GF['cuda']))

                for index_optimizer in range(len(names_optimizer)):  # 遍历所有优化器
                    name_optimizer = names_optimizer[index_optimizer]
                    alg.set_optimizer(name_optimizer)
                    print('————————————完成%s优化器构造（是否在CUDA上:%s）' % (name_optimizer, config_GF['cuda']))

                    #################训练网络（优化网络权重）########################################################################################################################################################
                    print('————————————开始训练网络————————————————————————————————————————————————————————————————————')
                    print(f'  数据集:{name_dataset}    损失函数:{name_loss_f}    模型:{name_model}    优化器:{name_optimizer}')
                    # 日志文件名自动拼接，无需手动修改
                    log_name = f'{name_dataset}_{name_model}_{name_loss_f}_{name_optimizer}'
                    log = Log(os.path.join(config_GF['path_logs'], log_name))    #记录训练过程中的loss
                    alg.train(log)  #model因为是浅拷贝，已在函数中被修改
                    print('————————————完成训练网络—————————————————————————————————————————————————————————————————————')
                    # 模型保存路径自动拼接，无需手动修改
                    model_save_path = os.path.join(config_GF['path_trained_model_weights'], f'{log_name}.pth')
                    torch.save(alg.model.state_dict(), model_save_path) #保存模型参数
                    print(f'在{name_dataset}上训练后的{name_model}模型参数已保存在: {model_save_path}')
                    #________________________________________________________________________________________________________________________________________________________________________________________________________


    total_end = time.time()
    print(f'————————————所有任务完成（总耗时：%.2f秒）————————————' % (total_end - total_start))