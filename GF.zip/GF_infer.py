# -*- coding: utf-8 -*-
"""
@author: ZYW
推理阶段入口脚本
"""
##命名规范#################################################################################################################################
#类名：AaBb
#文件名、变量名、函数名：aa_bb，其中如遇专有名词则保持专有名词大写
#_________________________________________________________________________________________________________________________________________

import os
import sys
import torch
import time
from utils.others import check_config, warning, get_class_label

##导入算法
from algs.YOLOv3.alg_YOLOv3 import Alg_YOLOv3
from algs.LeNet5.alg_LeNet5 import Alg_LeNet5


##############支持的数据集、模型和优化器#######################################################################################################
names_dataset_surported     = ['VOC2007', 'VOC2007MiniTest', 'MNIST', 'TC']  # 支持的数据集
names_model_surported       = ['YOLOv3', 'LeNet5', 'SSDlite']  # 支持的模型列表
names_loss_f_surported      = ['default', 'BCE', 'CE']  # 支持的损失函数列表
names_optimizer_surported   = ['Adam', 'PSO', 'PSO_CUDA', 'PSO_AC_CUDA']  # 支持的优化器列表

# 模型类型分类（用于判断调用哪个推理方法）
classification_models = ['LeNet5']  # 分类模型
detection_models = ['YOLOv3']  # 目标检测模型
#________________________________________________________________________________________________________________________________________


##############参数设置######################################################################################################################
##待推理的实验组合（需要与训练时保持一致）
names_dataset = names_dataset_surported[2:3]         # 选择数据集
names_model = names_model_surported[1:2]             # 选择模型
names_loss_f = names_loss_f_surported[0:1]           # 选择损失函数
names_optimizer = names_optimizer_surported[2:3]     # 选择优化器


##参数配置（复用训练阶段的核心逻辑，同时添加推理专用参数）
config_GF = {
    # 训练、验证、测试集的占比（推理阶段不使用，但check_config需要此参数）
    'dataset_ratio'                 : [0.85, 0.15, 0],
    # 加载数据集的子进程数
    'num_works'                     : 4,
    # 输入的图像大小（需与训练时一致）
    'input_shape'                   : (32, 32),
    # 是否使用GPU
    'cuda'                          : True,
    # 数据集是否作标准化处理（需与训练时一致）
    'dataset_normalize'             : {'is': True,
                                       'values': [[0.1307], [0.3081]]},
    
    ##路径设置#####################################################################################
    # 数据集的路径（用于读取类别标签）
    'path_dataset'                  : os.path.join('.', 'dataset'),
    # 训练后模型权重的路径
    'path_trained_model_weights'    : os.path.join('.', 'trained_model_weights'),
    # 待推理图像的路径（Iamges_to_infer文件夹，论文中的拼写）
    'path_images_to_infer'          : os.path.join('.', 'images_to_infer'),
    # 推理结果保存路径（Infer子文件夹）
    'path_infer_results'            : os.path.join('.', 'images_to_infer', 'Infer'),
    #__________________________________________________________________________________________________
    
    ##推理专用参数#####################################################################################
    # 是否给图像增加灰条（保持不失真resize）
    'gray_bar'                      : True,
    
    # 是否保存带标签的结果图像
    'save_box_label'                : {
        'is': True,  # 是否保存
        'path': os.path.join('.', 'images_to_infer', 'Infer'),  # 保存路径（会在运行时自动创建子文件夹）
        'font': os.path.join('.', 'algs', 'YOLOv3', 'model_data', 'simhei.ttf'),  # 字体路径
        'font_size': 15,  # 字体大小
        'thickness': 2  # 边框线粗
    },
    
    # 目标检测专用参数（仅对YOLOv3等检测模型有效）
    'thres_conf'                    : 0.5,   # 置信度阈值
    'thres_iou'                     : 0.3,   # IOU阈值（非极大抑制）
    
    # 是否裁剪检测到的目标并单独保存
    'crop'                          : {
        'is': False,  # 是否裁剪
        'path': os.path.join('.', 'images_to_infer', 'Infer', 'crop')  # 裁剪图像保存路径
    },
    #__________________________________________________________________________________________________
}
#________________________________________________________________________________________________________________________________________

# 固定使用的GPU编号
if config_GF['cuda']:
    torch.cuda.set_device(0)


##############辅助函数（用于推理阶段）######################################################################################################################
class InferenceLog:
    """简单的推理日志类（与训练时的Log类接口兼容）"""
    def __init__(self, result_path):
        self.result_path = result_path
        self.path_save = result_path
        

def create_infer_result_directory(name_dataset, name_model, name_loss_f, name_optimizer):
    """创建推理结果保存目录（按实验组合和时间戳命名）"""
    import datetime
    curr_time = datetime.datetime.now()
    time_str = datetime.datetime.strftime(curr_time, '%Y_%m_%d_%H_%M_%S')
    
    # 按"数据集_模型_损失函数_优化器_时间戳"命名
    result_folder_name = f"{name_dataset}_{name_model}_{name_loss_f}_{name_optimizer}_{time_str}"
    result_path = os.path.join(config_GF['path_infer_results'], result_folder_name)
    
    if not os.path.exists(result_path):
        os.makedirs(result_path)
    
    # 更新配置中的保存路径
    config_GF['save_box_label']['path'] = result_path
    config_GF['crop']['path'] = os.path.join(result_path, 'crop')
    
    return result_path


def create_inference_log(result_path, name_dataset, name_model, name_loss_f, name_optimizer, 
                        path_model_weights, path_images, num_images, inference_time):
    """创建推理日志文件"""
    log_path = os.path.join(result_path, 'inference_log.txt')
    
    with open(log_path, 'w', encoding='utf-8') as f:
        f.write('=' * 80 + '\n')
        f.write('推理日志\n')
        f.write('=' * 80 + '\n\n')
        
        f.write('[实验配置]\n')
        f.write(f'数据集: {name_dataset}\n')
        f.write(f'模型: {name_model}\n')
        f.write(f'损失函数: {name_loss_f}\n')
        f.write(f'优化器: {name_optimizer}\n')
        f.write(f'模型权重路径: {path_model_weights}\n\n')
        
        f.write('[推理信息]\n')
        f.write(f'待推理图像路径: {path_images}\n')
        f.write(f'推理图像数量: {num_images}\n')
        f.write(f'总耗时: {inference_time:.2f}秒\n')
        if num_images > 0:
            f.write(f'平均每张图像耗时: {inference_time/num_images:.4f}秒\n\n')
        
        f.write('[推理参数]\n')
        f.write(f'输入尺寸: {config_GF["input_shape"]}\n')
        f.write(f'是否使用GPU: {config_GF["cuda"]}\n')
        f.write(f'是否标准化: {config_GF["dataset_normalize"]["is"]}\n')
        if name_model in detection_models:
            f.write(f'置信度阈值: {config_GF["thres_conf"]}\n')
            f.write(f'IOU阈值: {config_GF["thres_iou"]}\n')
        
        f.write('\n' + '=' * 80 + '\n')
        f.write('推理完成！结果已保存至当前目录。\n')
        f.write('=' * 80 + '\n')
    
    print(f'推理日志已保存至: {log_path}')
#________________________________________________________________________________________________________________________________________


if __name__ == "__main__":
    
    total_start = time.time()   # 总耗时计时开始
    
    # 判断参数设置正误
    if check_config(config_GF):
        print('参数配置错误' + warning[0])
        sys.exit()
    
    # 清空cuda中未占用的显存
    if config_GF['cuda']:
        torch.cuda.empty_cache()
    
    print('=' * 100)
    print('推理阶段'.center(100))
    print('=' * 100)
    
    # 遍历所有实验组合进行推理
    for index_dataset in range(len(names_dataset)):
        name_dataset = names_dataset[index_dataset]
        
        #################获取类别标签和待推理图像路径###########################################################################################################################################################################
        # 获取类别标签文件路径
        path_class_labels = os.path.join(config_GF['path_dataset'], name_dataset, 'class_labels.txt')
        if not os.path.exists(path_class_labels):
            print(f'警告：未找到类别标签文件：{path_class_labels}' + warning[0])
            continue
        
        # 获取待推理图像路径（支持按数据集分类存储或直接存放在根目录）
        path_images_dataset = os.path.join(config_GF['path_images_to_infer'], name_dataset)
        if os.path.exists(path_images_dataset):
            path_images = path_images_dataset
        elif os.path.exists(config_GF['path_images_to_infer']):
            path_images = config_GF['path_images_to_infer']
        else:
            print(f'警告：未找到待推理图像路径：{config_GF["path_images_to_infer"]}' + warning[0])
            print('请创建该文件夹并放入待推理的图像。')
            continue
        
        # 统计待推理图像数量
        num_images = len([f for f in os.listdir(path_images) 
                         if f.lower().endswith(('.bmp', '.dib', '.png', '.jpg', '.jpeg', 
                                               '.pbm', '.pgm', '.ppm', '.tif', '.tiff'))])
        
        if num_images == 0:
            print(f'警告：在 {path_images} 中未找到任何图像文件，跳过该数据集。')
            continue
        
        print(f'\n数据集: {name_dataset}')
        print(f'待推理图像路径: {path_images}')
        print(f'待推理图像数量: {num_images}')
        # ________________________________________________________________________________________________________________________________________________________________________________________________________
        
        for index_model in range(len(names_model)):
            name_model = names_model[index_model]
            
            for index_loss_f in range(len(names_loss_f)):
                name_loss_f = names_loss_f[index_loss_f]
                
                for index_optimizer in range(len(names_optimizer)):
                    name_optimizer = names_optimizer[index_optimizer]
                    
                    print('\n' + '-' * 100)
                    print(f'推理组合: {name_dataset} + {name_model} + {name_loss_f} + {name_optimizer}')
                    print('-' * 100)
                    
                    #################获取模型权重路径###########################################################################################################################################################################
                    # 根据实验组合生成模型权重文件路径
                    path_model_weights = os.path.join(
                        config_GF['path_trained_model_weights'], 
                        f"{name_dataset}_{name_model}_{name_loss_f}_{name_optimizer}.pth"
                    )
                    
                    if not os.path.exists(path_model_weights):
                        print(f'警告：未找到模型权重文件：{path_model_weights}')
                        print('请确认该模型已完成训练，或检查文件名是否正确。')
                        continue
                    
                    print(f'加载模型权重: {path_model_weights}')
                    # ________________________________________________________________________________________________________________________________________________________________________________________________________
                    
                    #################创建推理结果保存目录###########################################################################################################################################################################
                    result_path = create_infer_result_directory(name_dataset, name_model, 
                                                                name_loss_f, name_optimizer)
                    print(f'推理结果将保存至: {result_path}')
                    # ________________________________________________________________________________________________________________________________________________________________________________________________________
                    
                    #################算法构建环节（直接复用algs文件夹的算法脚本）###########################################################################################################################################################################
                    # 创建算法对象（推理模式：is_train=False）
                    try:
                        alg = eval(f'Alg_{name_model}(is_train=False, config_GF=config_GF, '
                                  f'path_model_weights=path_model_weights, '
                                  f'path_class_labels=path_class_labels)')
                        print(f'————————————完成{name_model}算法对象创建（推理模式）')
                    except Exception as e:
                        print(f'创建算法对象失败: {str(e)}' + warning[0])
                        continue
                    
                    # 加载模型结构和训练后权重
                    try:
                        alg.set_model()
                        print(f'————————————完成{name_model}网络模型构造和权重加载（是否在CUDA上: {config_GF["cuda"]}）')
                    except Exception as e:
                        print(f'加载模型失败: {str(e)}' + warning[0])
                        continue
                    # ________________________________________________________________________________________________________________________________________________________________________________________________________
                    
                    #################数据处理与推理执行###########################################################################################################################################################################
                    # 创建日志对象
                    log = InferenceLog(result_path)
                    
                    print(f'————————————开始推理————————————————————————————————————————————————————————————————————')
                    inference_start = time.time()
                    
                    try:
                        # 根据模型类型调用不同的推理方法
                        if name_model in classification_models:
                            # 分类任务：调用 predict() 方法
                            alg.predict(path_images, log)
                            print(f'————————————完成分类推理')
                        elif name_model in detection_models:
                            # 目标检测任务：调用 detect() 方法
                            alg.detect(path_images, log)
                            print(f'————————————完成目标检测')
                        else:
                            print(f'警告：未知的模型类型 {name_model}，跳过推理')
                            continue
                    except Exception as e:
                        print(f'推理过程出错: {str(e)}' + warning[0])
                        import traceback
                        traceback.print_exc()
                        continue
                    
                    inference_end = time.time()
                    inference_time = inference_end - inference_start
                    
                    print(f'推理总耗时: {inference_time:.2f}秒')
                    if num_images > 0:
                        print(f'平均每张图像耗时: {inference_time/num_images:.4f}秒')
                    # ________________________________________________________________________________________________________________________________________________________________________________________________________
                    
                    #################生成推理日志###########################################################################################################################################################################
                    create_inference_log(result_path, name_dataset, name_model, name_loss_f, 
                                       name_optimizer, path_model_weights, path_images, 
                                       num_images, inference_time)
                    
                    print(f'推理结果已保存至: {result_path}')
                    print('-' * 100)
                    # ________________________________________________________________________________________________________________________________________________________________________________________________________
    
    total_end = time.time()
    print('\n' + '=' * 100)
    print(f'所有推理任务完成！总耗时: {total_end - total_start:.2f}秒')
    print('=' * 100)
