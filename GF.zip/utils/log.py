# -*- coding: utf-8 -*-
"""
@author: ZYW
"""
import os
import scipy.signal
from matplotlib import pyplot as plt

import matplotlib
matplotlib.use('Agg')   #防止下面plt显示时出现如下错误：“QXcbConnection: Could not connect to display localhost”

#######################记录训练和检测过程########################################################################################
class Log():    #参考：github上的yolo3-pytorch-master（202107）
    def __init__(self, path_log):
        import datetime
        curr_time = datetime.datetime.now()
        time_str = datetime.datetime.strftime(curr_time, '%Y_%m_%d_%H_%M_%S')
        self.path_log = path_log
        self.time_str = time_str
        self.path_save = os.path.join(self.path_log, "loss_" + str(self.time_str))
        self.loss_train = []
        self.loss_val = []

        self.accuracies = []   #新加入的，准确率变化
        os.makedirs(self.path_save)


    def append_loss(self, loss_train, loss_val):
        self.loss_train.append(loss_train)
        self.loss_val.append(loss_val)
        with open(os.path.join(self.path_save, "epoch_train_loss_" + str(self.time_str) + ".txt"), 'a') as f:
            f.write(str(loss_train))
            f.write("\n")
        with open(os.path.join(self.path_save, "epoch_val_loss_" + str(self.time_str) + ".txt"), 'a') as f:
            f.write(str(loss_val))
            f.write("\n")
        self.loss_plot()


    def append_accuracies(self, accuracy_dict):
        self.accuracies.append(accuracy_dict)  # 保存准确率字典
        # 将准确率写入文本文件（文件名称也体现准确率）
        with open(os.path.join(self.path_save, "epoch_accuracies_" + str(self.time_str) + ".txt"), 'a') as f:
            f.write(str(accuracy_dict))  # 写入格式：{'acc_train': 0.69, 'acc_val': 0.93}
            f.write("\n")
        self.accuracy_plot()


    def loss_plot(self):
        iters = range(len(self.loss_train))

        plt.figure()
        plt.plot(iters, self.loss_train, 'red', linewidth=2, label='train loss')
        plt.plot(iters, self.loss_val, 'coral', linewidth=2, label='val loss')
        try:
            if len(self.loss_train) < 25:
                num = 5
            else:
                num = 15

            plt.plot(iters, scipy.signal.savgol_filter(self.loss_train, num, 3), 'green', linestyle='-', linewidth=2, label='smooth train loss')
            plt.plot(iters, scipy.signal.savgol_filter(self.loss_val, num, 3), '#8B4513', linestyle='--', linewidth=2, label='smooth val loss')
        except:
            pass

        # plt.grid(True)
        plt.xlabel('Epoch')
        plt.ylabel('Loss')
        plt.legend(loc="upper right")

        plt.savefig(os.path.join(self.path_save, "epoch_loss_" + str(self.time_str) + ".png"))

        plt.cla()
        plt.close("all")


    def accuracy_plot(self):
        # 提取准确率数据
        acc_train = [item['acc_train'] for item in self.accuracies]
        acc_val = [item['acc_val'] for item in self.accuracies]
        iters = range(len(acc_train))

        plt.figure()
        # 绘制准确率曲线
        plt.plot(iters, acc_train, 'blue', linewidth=2, label='train accuracy')
        plt.plot(iters, acc_val, 'cyan', linewidth=2, label='val accuracy')
        # 平滑曲线
        try:
            num = 5 if len(acc_train) < 25 else 15
            plt.plot(iters, scipy.signal.savgol_filter(acc_train, num, 3), 'darkblue', linestyle='-', linewidth=2,
                     label='smooth train accuracy')
            plt.plot(iters, scipy.signal.savgol_filter(acc_val, num, 3), 'teal', linestyle='--', linewidth=2,
                     label='smooth val accuracy')
        except:
            pass
        # 坐标轴与保存（准确率范围0-1.05更合理）
        plt.xlabel('Epoch')
        plt.ylabel('Accuracy')
        plt.ylim(0, 1.05)
        plt.legend(loc="lower right")
        plt.savefig(os.path.join(self.path_save, "epoch_accuracy_" + str(self.time_str) + ".png"))
        plt.cla()
        plt.close("all")