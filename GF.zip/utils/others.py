# -*- coding: utf-8 -*-
"""
@author: ZYW
"""
import os
import torch
from tqdm import tqdm
import numpy as np
from PIL import Image

warning = ['程序非正常退出！']

#######################判断参数########################################################################################
def  check_config(config_GF):
    err = False
    #######判断config_GF参数##########################################
    if (not torch.cuda.is_available()) and (config_GF['cuda'] == True):
        err = True
        print('参数配置（config_GF）中的cuda值与实际硬件不一致。' + warning[0])
    if sum(config_GF['dataset_ratio']) != 1:
        err = True
        print('参数配置（config_GF）中的dataset_ratio中各比例之和不等于1。' + warning[0])
    #__________________________________________________________________________

    return err
#________________________________________________________________________________________________________________________________


###############初始化权重参数##########################################################################################################
def init_weights(model, init_type='normal', init_gain=0.02):         # init_gain 为初始化的增益，些初始化方式有用
    def init_func(m):
        classname = m.__class__.__name__
        if hasattr(m, 'weight') and classname.find('Conv') != -1:
            if init_type == 'normal':
                torch.nn.init.normal_(m.weight.data, 0.0, init_gain)
            elif init_type == 'xavier':
                torch.nn.init.xavier_normal_(m.weight.data, gain=init_gain)
            elif init_type == 'kaiming':
                torch.nn.init.kaiming_normal_(m.weight.data, a=0, mode='fan_in')
            elif init_type == 'orthogonal':
                torch.nn.init.orthogonal_(m.weight.data, gain=init_gain)
            else:
                raise NotImplementedError('initialization method [%s] is not implemented' % init_type)
        elif classname.find('BatchNorm2d') != -1:
            torch.nn.init.normal_(m.weight.data, 1.0, 0.02)
            torch.nn.init.constant_(m.bias.data, 0.0)

    model.apply(init_func)  #init_func不带括号时，调用的是这个函数本身
    print('  完成自定义初始化网络权重！（方式为：%s）' %(init_type))
#________________________________________________________________________________________________________________________________


###############加载模型权重##########################################################################################################
def load_model_weights(model, path_model_weights, cuda):
    device = torch.device('cuda' if cuda else 'cpu')
    model_dict = model.state_dict()                                    # 获取当前模型的所有参数字典
    dict = torch.load(path_model_weights, map_location=device)         # 映射到设备上

    dict = {k: v for k, v in dict.items() if (k in model_dict) and np.shape(model_dict[k]) == np.shape(v)}
            #既判断模型键名称，也判断该值数据维数
    # dict = {k: v for k, v in dict.items() if np.shape(model_dict[k]) == np.shape(v)}
    #             #只取原模型和预训练模型中均有的权重参数，即可能预训练模型中的部分权重参数没有被利用，也可能原模型中的部分权重参数在下面没有被更新

    model_dict.update(dict)
    model.load_state_dict(model_dict)

    print('  完成预训练模型参数加载！')
#________________________________________________________________________________________________________________________________


##加载类别##############################################################################################################
def get_class_label(path_class_label):            #把每一行读出来，去掉末尾空格和换行符
    with open(path_class_label, encoding='utf-8') as f:
        class_label = f.readlines()
    class_label = [c.strip() for c in class_label]
    return class_label
#________________________________________________________________________________________________________________________________


##获取优化器中的学习率##############################################################################################################
def get_lr(optimizer):
    for param_group in optimizer.param_groups:
        return param_group['lr']
#________________________________________________________________________________________________________________________________


#---------------------------------------------------------#
#   将图像转换成RGB图像，防止灰度图在预测时报错。
#   代码仅仅支持RGB图像的预测，所有其它类型的图像都会转化成RGB
#---------------------------------------------------------#
def cvtColor(image):
    if len(np.shape(image)) == 3 and np.shape(image)[2] == 3:
        return image
    else:
        image = image.convert('RGB')
        return image

# ---------------------------------------------------#
#   对输入图像进行resize，并可以选择缩放后是否加灰度条以保持和原图同大小
# ---------------------------------------------------#
def resize_image(image, size, gray_bar):
    iw, ih = image.size
    w, h = size
    if gray_bar:
        scale = min(w / iw, h / ih)
        nw = int(iw * scale)
        nh = int(ih * scale)

        image = image.resize((nw, nh), Image.BICUBIC)
        new_image = Image.new('RGB', size, (128, 128, 128))
        new_image.paste(image, ((w - nw) // 2, (h - nh) // 2))
    else:
        new_image = image.resize((w, h), Image.BICUBIC)
    return new_image

# ---------------------------------------------------#
#   把图像归一化，即把像素值线性转换到[0,1]区间
# ---------------------------------------------------#
def normalize(image):
    image /= 255.0
    return image