# -*- coding: utf-8 -*-
"""
@author: ZYW
"""

import sys
import copy
import torch
import torch.optim as optim
import numba
from numba import cuda
from utils.cuda_kernels import *

##优化器########################################################################################################################
##部分优化器来自于pytorch官方：https://pytorch.org/docs/stable/optim.html
def create_optimizer(optimizer_name, model, **kwargs):#参数:优化器名，模型，可变长参数
    if optimizer_name == 'Adam':
        optimizer = optim.Adam(model.parameters(), **kwargs)
    elif optimizer_name == 'SGD':
        optimizer = optim.SGD(model.parameters(), **kwargs)
    elif optimizer_name == 'PSO':
        optimizer = PSO(config_PSO, model)
    elif optimizer_name == 'PSO_CUDA':
        optimizer = PSO_CUDA(config_PSO, model)
    elif optimizer_name == 'PSO_AC_CUDA':
        optimizer = PSO_AC_CUDA(
            config_PSO,
            model,
            total_steps=kwargs.get('total_steps')  # 传递给优化器
        )
    else:
        print('不支持所指定的优化器%s！'%(optimizer_name))
        sys.exit()

    return optimizer

##创建PSO
config_PSO = {
    'nP': 50,
    'w': 0.72984,
    'c1': 0.72984 * 4.1 / 2,
    'c2': 0.72984 * 4.1 / 2,
    'v_min': -0.1,
    'v_max': 0.1,
    'x_min': -1.0,
    'x_max': 1.0,
    'C_start': 1.1,
    'C_end': 0.8,
    'G_start': 1.0,
    'G_end': 0.9
}


class PSO():  # CPU版本
    def __init__(self, config, model):
        self.model = model
        self.nP = config['nP']
        self.w = config['w']
        self.c1 = config['c1']
        self.c2 = config['c2']
        self.v_min = config['v_min']
        self.v_max = config['v_max']
        self.x_min = config['x_min']
        self.x_max = config['x_max']

        # 解析模型参数
        params = list(self.model.parameters())
        self.param_shapes = [p.shape for p in params]  # 每层参数形状
        self.param_numels = [torch.prod(torch.tensor(shape)).item() for shape in self.param_shapes]  # 每层参数数量
        self.dim = sum(self.param_numels)  # 总参数维度

        base_params = [p.data.clone().cpu() for p in params]  # 强制CPU
        self.base_flat = torch.cat([p.flatten() for p in base_params])  # 展平的基准参数
        self.std_flat = torch.cat([p.std().repeat(numel) for p, numel in zip(base_params, self.param_numels)])  # 标准差

        self.position = torch.zeros(self.nP, self.dim)
        self.velocities = torch.zeros(self.nP, self.dim)
        for i in range(self.nP):
            noise = torch.randn_like(self.base_flat) * self.std_flat
            self.position[i] = torch.clamp(self.base_flat + noise, self.x_min, self.x_max)
            self.velocities[i] = torch.rand_like(self.position[i]) * (self.v_max - self.v_min) + self.v_min

        self.current_fitness = [float('inf')] * self.nP
        self.pbest_positions = self.position.clone()
        self.pbest_fitness = [float('inf')] * self.nP
        self.gbest_position = self.position[0].clone()
        self.gbest_fitness = float('inf')

    def step(self, images, targets, loss_f, timer):
        timer.start_stage("PSO-适应度评价")
        self.evaluate_particle(images, targets, loss_f)
        timer.end_stage()

        timer.start_stage("PSO-更新个体最优")
        self.update_pbest()
        timer.end_stage()

        timer.start_stage("PSO-更新全局最优")
        self.update_gbest()
        timer.end_stage()

        timer.start_stage("PSO-更新位置和速度")
        self.update_particle()
        timer.end_stage()

        self.set_main_model_weights(self.gbest_position)

    def evaluate_particle(self, images, targets, loss_f):
        for i in range(self.nP):
            self.set_particle_model_weights(self.position[i])
            self.model.eval()
            with torch.no_grad():
                outputs = self.model(images)
                loss = loss_f(outputs, targets)
                self.current_fitness[i] = loss.item()

    def update_particle(self,):
        r1 = torch.rand_like(self.position)
        r2 = torch.rand_like(self.position)
        self.velocities = (
            self.w * self.velocities
            + self.c1 * r1 * (self.pbest_positions - self.position)
            + self.c2 * r2 * (self.gbest_position.unsqueeze(0) - self.position)
        )
        self.velocities = torch.clamp(self.velocities, self.v_min, self.v_max)
        self.position = self.position + self.velocities
        self.position = torch.clamp(self.position, self.x_min, self.x_max)

    def update_pbest(self,):
        for i in range(self.nP):
            if self.current_fitness[i] < self.pbest_fitness[i]:
                self.pbest_fitness[i] = self.current_fitness[i]
                self.pbest_positions[i] = self.position[i].clone()

    def update_gbest(self,):
        for i in range(self.nP):
            if self.current_fitness[i] < self.gbest_fitness:
                self.gbest_fitness = self.current_fitness[i]
                self.gbest_position = self.position[i].clone()

    def set_particle_model_weights(self, flat_weights):
        with torch.no_grad():
            ptr = 0
            for p, shape, numel in zip(self.model.parameters(), self.param_shapes, self.param_numels):
                layer_params = flat_weights[ptr:ptr+numel].view(shape).to(p.device)
                p.copy_(layer_params)
                ptr += numel

    def set_main_model_weights(self, flat_weights):
        self.set_particle_model_weights(flat_weights)


class PSO_CUDA():  # GPU版本
    def __init__(self, config, model):
        self.model = model
        self.nP = config['nP']
        self.w = config['w']
        self.c1 = config['c1']
        self.c2 = config['c2']
        self.v_min = config['v_min']
        self.v_max = config['v_max']
        self.x_min = config['x_min']
        self.x_max = config['x_max']

        params = list(self.model.parameters())
        self.param_shapes = [p.shape for p in params]
        self.param_numels = [torch.prod(torch.tensor(shape)).item() for shape in self.param_shapes]
        self.dim = sum(self.param_numels)

        base_params = [p.data.clone().cuda().contiguous() for p in params]
        self.base_flat = torch.cat([p.flatten() for p in base_params]).contiguous()
        self.std_flat = torch.cat([p.std().repeat(numel) for p, numel in zip(base_params, self.param_numels)]).cuda().contiguous()

        self.position = torch.zeros(self.nP, self.dim, device=self.base_flat.device).contiguous()
        self.velocities = torch.zeros(self.nP, self.dim, device=self.base_flat.device).contiguous()
        noise = torch.randn(self.nP, self.dim, device=self.base_flat.device).contiguous() * self.std_flat
        self.position = (self.base_flat.unsqueeze(0).repeat(self.nP, 1) + noise).clamp(self.x_min, self.x_max).contiguous()
        self.velocities = (torch.rand(self.nP, self.dim, device=self.base_flat.device).contiguous() * (self.v_max - self.v_min) + self.v_min).contiguous()

        # 粒子模型副本
        self.particle_models = [copy.deepcopy(self.model).cuda() for _ in range(self.nP)]
        self.gpu_streams = [torch.cuda.Stream() for _ in range(self.nP)]  # 多流并行

        self.current_fitness = torch.full((self.nP,), float('inf'), device=self.base_flat.device).contiguous()
        self.pbest_positions = self.position.clone().contiguous()
        self.pbest_fitness = torch.full((self.nP,), float('inf'), device=self.base_flat.device).contiguous()
        self.gbest_position = self.position[0].clone().contiguous()
        self.gbest_fitness = torch.tensor(float('inf'), device=self.base_flat.device).contiguous()

        # CUDA配置
        self.threads_per_block = 128
        self.blocks = self.nP
        self.total_threads = self.blocks * self.threads_per_block
        self.rng_states = cuda.random.create_xoroshiro128p_states(
            self.total_threads, seed=torch.randint(0, 1024, ()).item()
        )

    def set_particle_model_weights(self, particle_model, flat_weights):
        with torch.no_grad():
            ptr = 0
            for p, shape, numel in zip(particle_model.parameters(), self.param_shapes, self.param_numels):
                p.copy_(flat_weights[ptr:ptr+numel].view(shape))
                ptr += numel

    def set_main_model_weights(self, flat_weights):
        with torch.no_grad():
            ptr = 0
            for p, shape, numel in zip(self.model.parameters(), self.param_shapes, self.param_numels):
                p.copy_(flat_weights[ptr:ptr+numel].view(shape))
                ptr += numel

    def evaluate_fitness_parallel(self, images, targets, loss_f):
        loss_buffers = [torch.tensor(0.0, device=self.base_flat.device) for _ in range(self.nP)]
        for i in range(self.nP):
            with torch.cuda.stream(self.gpu_streams[i]):
                self.set_particle_model_weights(self.particle_models[i], self.position[i])
                self.particle_models[i].eval()
                with torch.no_grad():
                    outputs = self.particle_models[i](images)
                    loss_buffers[i] = loss_f(outputs, targets).mean()
        torch.cuda.synchronize()
        for i in range(self.nP):
            self.current_fitness[i] = loss_buffers[i]

    def step(self, images, targets, loss_f, timer):
        timer.start_stage("PSO_CUDA-适应度评价")
        self.evaluate_fitness_parallel(images, targets, loss_f)
        timer.end_stage()

        pbest_fit_device = cuda.as_cuda_array(self.pbest_fitness)
        current_fit_device = cuda.as_cuda_array(self.current_fitness)
        gbest_fit_device = cuda.as_cuda_array(self.gbest_fitness.unsqueeze(0))
        vel_device = cuda.as_cuda_array(self.velocities)
        pos_device = cuda.as_cuda_array(self.position)
        pbest_pos_device = cuda.as_cuda_array(self.pbest_positions)
        gbest_pos_device = cuda.as_cuda_array(self.gbest_position)

        timer.start_stage("PSO_CUDA-更新个体最优")
        cuda_update_pbest_kernel[self.blocks, self.threads_per_block](
            self.nP, self.dim, pos_device, pbest_pos_device, current_fit_device, pbest_fit_device
        )
        cuda.synchronize()
        timer.end_stage()

        timer.start_stage("PSO_CUDA-更新全局最优")
        gbest_threads = min(self.nP, self.threads_per_block)
        cuda_update_gbest_kernel[1, gbest_threads](
            self.nP, self.dim, pbest_pos_device, pbest_fit_device, gbest_pos_device, gbest_fit_device
        )
        cuda.synchronize()
        self.gbest_fitness = torch.tensor(gbest_fit_device.copy_to_host()[0], device=self.base_flat.device)
        timer.end_stage()

        timer.start_stage("PSO_CUDA-更新位置和速度")
        cuda_update_particles_kernel[self.blocks, self.threads_per_block](
            self.nP, self.dim, pos_device, vel_device, pbest_pos_device, gbest_pos_device,
            self.w, self.c1, self.c2, self.v_min, self.v_max, self.x_min, self.x_max, self.rng_states
        )
        cuda.synchronize()
        timer.end_stage()

        self.set_main_model_weights(self.gbest_position)

class PSO_AC_CUDA(PSO_CUDA):
    def __init__(self, config, model, total_steps):
        super().__init__(config, model)

        self.total_steps = total_steps
        self.is_first_step = True
        self.old_position1 = torch.empty_like(self.position, device=self.position.device).contiguous()
        self.old_position1.copy_(self.position)
        self.old_position2 = torch.zeros_like(self.position, device=self.position.device).contiguous()

        self.C_start = config['C_start']
        self.C_end = config['C_end']
        self.G_start = config['G_start']
        self.G_end = config['G_end']

        self.C_decay_step = (self.C_start - self.C_end) / self.total_steps
        self.G_decay_step = (self.G_start - self.G_end) / self.total_steps

        self.C = self.C_start
        self.G = self.G_start

    def update_linear_decay(self):
        self.C = max(self.C - self.C_decay_step, self.C_end)
        self.G = max(self.G - self.G_decay_step, self.G_end)

    def step(self, images, targets, loss_f, timer):
        timer.start_stage("PSO_CUDA-适应度评价")
        self.evaluate_fitness_parallel(images, targets, loss_f)
        timer.end_stage()

        pbest_fit_device = cuda.as_cuda_array(self.pbest_fitness)
        current_fit_device = cuda.as_cuda_array(self.current_fitness)
        gbest_fit_device = cuda.as_cuda_array(self.gbest_fitness.unsqueeze(0))
        vel_device = cuda.as_cuda_array(self.velocities)
        pos_device = cuda.as_cuda_array(self.position)
        pbest_pos_device = cuda.as_cuda_array(self.pbest_positions)
        gbest_pos_device = cuda.as_cuda_array(self.gbest_position)
        oldpos1_device = cuda.as_cuda_array(self.old_position1)
        oldpos2_device = cuda.as_cuda_array(self.old_position2)

        timer.start_stage("PSO_AC_CUDA-更新个体最优")
        cuda_update_pbest_kernel[self.blocks, self.threads_per_block](
            self.nP, self.dim, pos_device, pbest_pos_device, current_fit_device, pbest_fit_device
        )
        cuda.synchronize()
        timer.end_stage()

        timer.start_stage("PSO_AC_CUDA-更新全局最优")
        gbest_threads = min(self.nP, self.threads_per_block)
        cuda_update_gbest_kernel[1, gbest_threads](
            self.nP, self.dim, pbest_pos_device, pbest_fit_device, gbest_pos_device, gbest_fit_device
        )
        cuda.synchronize()
        self.gbest_fitness = torch.tensor(
            gbest_fit_device.copy_to_host()[0],
            device=self.base_flat.device
        )
        timer.end_stage()

        timer.start_stage("PSO_AC_CUDA-更新位置和速度")
        self.update_linear_decay()
        cuda_update_particles_ac_kernel[self.blocks, self.threads_per_block](
            self.nP, self.dim, pos_device, vel_device, pbest_pos_device, gbest_pos_device,
            oldpos1_device, oldpos2_device, self.is_first_step, self.C, self.G,
            self.w, self.c1, self.c2, self.v_min, self.v_max, self.x_min, self.x_max, self.rng_states
        )
        cuda.synchronize()
        timer.end_stage()

        if self.is_first_step:
            self.is_first_step = False

        self.set_main_model_weights(self.gbest_position)



