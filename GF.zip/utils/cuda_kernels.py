# -*- coding: utf-8 -*-
"""
PSO_CUDA及PSO_CUDA_AC所需的CUDA内核函数
"""
import numba
import math
from numba import cuda
from numba.cuda.random import xoroshiro128p_uniform_float32


@cuda.jit
def cuda_update_particles_kernel(
        n, dim, position, velocity, pbest_position, gbest_position,
        w, c1, c2, v_min, v_max, x_min, x_max, rng_states
):
    particle_id = cuda.blockIdx.x
    if particle_id >= n:
        return
    thread_id = cuda.threadIdx.x
    stride = cuda.blockDim.x
    global_tid = particle_id * stride + thread_id
    for dim_id in range(thread_id, dim, stride):
        r1 = xoroshiro128p_uniform_float32(rng_states, global_tid)
        r2 = xoroshiro128p_uniform_float32(rng_states, global_tid)
        velocity[particle_id, dim_id] = w * velocity[particle_id, dim_id] + \
              c1 * r1 * (pbest_position[particle_id, dim_id] - position[particle_id, dim_id]) + \
              c2 * r2 * (gbest_position[dim_id] - position[particle_id, dim_id])
        velocity[particle_id, dim_id] = min(max(velocity[particle_id, dim_id], v_min), v_max)
        position[particle_id, dim_id] += velocity[particle_id, dim_id]
        position[particle_id, dim_id] = min(max(position[particle_id, dim_id], x_min), x_max)


@cuda.jit
def cuda_update_particles_ac_kernel(
        n, dim, position, velocity, pbest_position, gbest_position, old_position1 ,old_position2,
        is_first_step, C, G, w, c1, c2, v_min, v_max, x_min, x_max, rng_states
):
    particle_id = cuda.blockIdx.x
    if particle_id >= n:
        return
    thread_id = cuda.threadIdx.x
    stride = cuda.blockDim.x
    global_tid = particle_id * stride + thread_id
    for dim_id in range(thread_id, dim, stride):
        r1 = xoroshiro128p_uniform_float32(rng_states, global_tid)
        r2 = xoroshiro128p_uniform_float32(rng_states, global_tid)
        if is_first_step:
            old_position1[particle_id, dim_id] = position[particle_id, dim_id]
            velocity[particle_id, dim_id] = w * velocity[particle_id, dim_id] + \
                                            c1 * r1 * (pbest_position[particle_id, dim_id] - position[particle_id, dim_id]) + \
                                            c2 * r2 * (gbest_position[dim_id] - position[particle_id, dim_id])
            velocity[particle_id, dim_id] = min(max(velocity[particle_id, dim_id], v_min), v_max)
            position[particle_id, dim_id] += velocity[particle_id, dim_id]
            position[particle_id, dim_id] = min(max(position[particle_id, dim_id], x_min), x_max)
        else:
            old_position2[particle_id, dim_id] = old_position1[particle_id, dim_id]
            old_position1[particle_id, dim_id] = position[particle_id, dim_id]

            b1 = c1 * r1
            b2 = c2 * r2
            a1 = 1 + w - b1 - b2
            a2 = -w

            Q = (b1 * pbest_position[particle_id, dim_id] + b2 * gbest_position[dim_id]) / (b1 + b2)
            temp = (gbest_position[dim_id] + G * (Q - gbest_position[dim_id]) +
                    C * (a1 * (old_position1[particle_id, dim_id] - Q) + a2 * (old_position2[particle_id, dim_id] - Q)))
            velocity[particle_id, dim_id] = temp - position[particle_id, dim_id]
            velocity[particle_id, dim_id] = min(max(velocity[particle_id, dim_id], v_min), v_max)
            position[particle_id, dim_id] += velocity[particle_id, dim_id]
            position[particle_id, dim_id] = min(max(position[particle_id, dim_id], x_min), x_max)


@cuda.jit
def cuda_update_pbest_kernel(n, dim, position, pbest_position, fitness, pbest_fitness):
    particle_id = cuda.blockIdx.x
    if particle_id >= n:
        return
    thread_id = cuda.threadIdx.x
    stride = cuda.blockDim.x
    if fitness[particle_id] < pbest_fitness[particle_id]:
        for dim_id in range(thread_id, dim, stride):
            pbest_position[particle_id, dim_id] = position[particle_id, dim_id]
    cuda.syncthreads()
    if thread_id == 0 and fitness[particle_id] < pbest_fitness[particle_id]:
        pbest_fitness[particle_id] = fitness[particle_id]


@cuda.jit
def cuda_update_gbest_kernel(n, dim, pbest_position, pbest_fitness, gbest_position, gbest_fitness):
    particle_id = cuda.threadIdx.x
    thread_id = cuda.threadIdx.x
    temp_pbest_fitness = cuda.shared.array(shape=128, dtype=numba.float32)
    temp_pbest_index = cuda.shared.array(shape=128, dtype=numba.int32)
    if particle_id < n:
        temp_pbest_fitness[particle_id] = pbest_fitness[particle_id]
        temp_pbest_index[particle_id] = particle_id
        k = math.ceil(math.log2(n))
        stride = n
        for i in range(k):
            stride = (stride + 1) // 2
            if particle_id < stride and particle_id + stride < n:
                if temp_pbest_fitness[particle_id] > temp_pbest_fitness[particle_id + stride]:
                    temp_pbest_fitness[particle_id] = temp_pbest_fitness[particle_id + stride]
                    temp_pbest_index[particle_id] = temp_pbest_index[particle_id + stride]
    stride = cuda.blockDim.x
    cuda.syncthreads()
    if temp_pbest_fitness[0] < gbest_fitness[0]:
        for dim_id in range(thread_id, dim, stride):
            gbest_position[dim_id] = pbest_position[temp_pbest_index[0], dim_id]
        cuda.syncthreads()
        if thread_id == 0:
            gbest_fitness[0] = temp_pbest_fitness[0]