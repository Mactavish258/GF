# -*- coding: utf-8 -*-
"""
@author: ZYW
"""
import os
import numpy as np
import xml.etree.ElementTree as ET
from utils.others import get_class_label

##整理数据集为dataset_info.txt#######################################################################################################
class Dataset():
    def __init__(self, config_GF, name_dataset, need_update):#参数:数据集的名称，是否更新标注文件或图像文件，训练、验证、测试用数据集的比例
        self.config_GF = config_GF
        self.name_dataset = name_dataset
        self.class_labels = get_class_label(os.path.join(config_GF['path_dataset'], name_dataset, 'class_labels.txt'))
        #相当于get_class_label('./dataset/VOC2007MiniTest/class_labels.txt')

        self.num_total = 0
        self.num_train = 0
        self.num_test = 0
        self.num_val = 0

        self.num_classes = len(self.class_labels)  # 数据集的类别数
        print('当前数据集类别数为%d' % (self.num_classes))

        if need_update == True:
            self.create_dataset_info()
        else:
            with open(os.path.join(self.config_GF['path_dataset'], self.name_dataset, 'dataset_info.txt'),'r') as file_dataset_info:
                self.num_total = len(file_dataset_info.readlines())

            self.num_train = int(self.num_total * self.config_GF['dataset_ratio'][0])
            self.num_test = int(self.num_total * self.config_GF['dataset_ratio'][2])
            self.num_val = self.num_total - self.num_train - self.num_test


    ##整理数据集中的图片路径、目标标签和位置到dataset_info.txt中，并按训练集、验证集、测试集分配到dataset_info_train.txt、dataset_info_val.txt和dataset_info_test.txt
    def create_dataset_info(self):
        print('正在整理和分配数据集信息....')

        ##整理进dataset_info.txt#######################################################################################################
        path_dataset = os.path.join(self.config_GF['path_dataset'], self.name_dataset)
        path_annotations = os.path.join(path_dataset,'annotations')             #标签路径
        path_images = os.path.join(path_dataset,'images')                       #图像路径

        xml_filename_temp = os.listdir(path_annotations)                        #获取 annotations 文件夹中所有文件名
        xml_filenam_total = []
        for xml in xml_filename_temp:                                           #筛选出后缀是 .xml 的文件，作为有效标注文件，存入 xml_filenam_total 列表中
            if xml.endswith(".xml"):
                xml_filenam_total.append(xml)

        file_dataset_info = open(os.path.join(path_dataset, 'dataset_info.txt'), 'w+', encoding='utf-8')
        for xml_filename in xml_filenam_total:
            line = os.path.join(path_images, '%s.jpg') % (xml_filename[:-4])    #根据 XML 文件名，构造对应的图像文件路径（.jpg）并赋值给变量 line;去掉字符串最后四个字符,即.xml

            #处理各xml文件中的标注信息
            xml_file = open(os.path.join(path_annotations,'%s')%(xml_filename), encoding='utf-8')
            tree=ET.parse(xml_file)                                             #解析 XML 文件，生成一棵“树结构”，称为 ElementTree
            root = tree.getroot()                                               #获得树的根节点

            for obj in root.iter('object'):                                     #遍历 XML 文件中所有 <object> 节点
                difficult = 0
                if obj.find('difficult')!=None:                                 #如果有 <difficult> 字段，读取其值，否则默认 0
                    difficult = obj.find('difficult').text
                cls = obj.find('name').text                                     #找到 <name> 标签
                if cls not in self.class_labels or int(difficult)==1:           #如果类别名不在分类任务中 or  是难以识别的  就跳过
                    continue
                cls_id = self.class_labels.index(cls)
                xmlbox = obj.find('bndbox')                                     #xmlbox 是 <bndbox> 标签，表示边界框
                b = (int(float(xmlbox.find('xmin').text)), int(float(xmlbox.find('ymin').text)), int(float(xmlbox.find('xmax').text)), int(float(xmlbox.find('ymax').text)))
                line = line + " " + ",".join([str(a) for a in b]) + ',' + str(cls_id)

            line = line + '\n'
            file_dataset_info.write(line)
        #______________________________________________________________________________________________________________________

        ##重新分配训练集、验证集、测试集#######################################################################################################
        self.num_total = len(xml_filenam_total)
        self.num_train = int(self.num_total * self.config_GF['dataset_ratio'][0])
        self.num_test = int(self.num_total * self.config_GF['dataset_ratio'][2])
        self.num_val = self.num_total - self.num_train - self.num_test

        file_dataset_info_train = open(os.path.join(path_dataset, 'dataset_info_train.txt'), 'w', encoding='utf-8')
        file_dataset_info_val = open(os.path.join(path_dataset, 'dataset_info_val.txt'), 'w', encoding='utf-8')
        file_dataset_info_test = open(os.path.join(path_dataset, 'dataset_info_test.txt'), 'w', encoding='utf-8')

        file_dataset_info.seek(0,0)                                             #把文件指针移动到文件开头，也就是从头开始读取文件
        lines = file_dataset_info.readlines()
        np.random.shuffle(lines)                                                #打乱所有行的顺序
        file_dataset_info_train.writelines( lines[:self.num_train])
        file_dataset_info_val.writelines(lines[self.num_train : self.num_train+self.num_val])
        file_dataset_info_test.writelines(lines[self.num_train+self.num_val:])
        #______________________________________________________________________________________________________________________

        file_dataset_info.close()
        file_dataset_info_train.close()
        file_dataset_info_val.close()
        file_dataset_info_test.close()

        print('  共有图像%d张，标注数据信息整理和重新分配完毕，存储在:%s' % (self.num_total, os.path.join(path_dataset, 'dataset_info.txt, dataset_info_train.txt, dataset_info_val.txt, dataset_info_test.txt')))

    ##获取dataset_info_train.txt的路径
    def get_path_train(self):
        return os.path.join(self.config_GF['path_dataset'], self.name_dataset, 'dataset_info_train.txt')

    ##获取dataset_info_val.txt的路径
    def get_path_val(self):
        return os.path.join(self.config_GF['path_dataset'], self.name_dataset, 'dataset_info_val.txt')

    ##获取dataset_info_test.txt的路径
    def get_path_test(self):
        return os.path.join(self.config_GF['path_dataset'], self.name_dataset, 'dataset_info_test.txt')