# utils/analysis.py
import time
from collections import defaultdict
import matplotlib.pyplot as plt
import numpy as np

class TrainTimer:
    """训练阶段计时工具：记录各阶段耗时并支持直方图绘制"""
    def __init__(self):
        self.stage_times = defaultdict(float)  # 存储各阶段总耗时
        self.current_stage = None
        self.start = 0

    def start_stage(self, stage_name):
        """开始记录某个阶段的耗时"""
        self.current_stage = stage_name
        self.start = time.time()

    def end_stage(self):
        """结束当前阶段计时并累计耗时"""
        if self.current_stage is None:
            return
        elapsed = time.time() - self.start
        self.stage_times[self.current_stage] += elapsed
        self.current_stage = None

    def reset(self):
        """重置计时（用于多轮训练时区分每轮耗时）"""
        self.stage_times.clear()
        self.current_stage = None

    def plot_histogram(self, save_path=None):
        plt.rcParams["font.family"] = ["SimHei", "Microsoft YaHei"]
        plt.rcParams["axes.unicode_minus"] = False

        # 获取所有阶段名称和耗时
        stages = list(self.stage_times.keys())
        durations = list(self.stage_times.values())
        num_stages = len(stages)

        # 1. 根据阶段数量动态调整图表宽度
        base_width = 8
        dynamic_width = base_width + num_stages * 0.8  # 每个阶段分配足够横向空间
        plt.figure(figsize=(dynamic_width, 7))  # 增加高度，为顶部标签预留空间

        # 2. 绘制柱状图
        bars = plt.bar(stages, durations, color='skyblue')

        # 3. 标题和坐标轴设置
        plt.title('权重优化各阶段耗时分布', pad=20)
        plt.xlabel('训练阶段', labelpad=15)
        plt.ylabel('总耗时（秒）', labelpad=15)

        # 4. 标签旋转设置（根据长度自适应）
        max_label_length = max(len(stage) for stage in stages)
        rotation = 45 if max_label_length > 4 else 30
        plt.xticks(rotation=rotation, ha='right')

        # 5. 确保数值标签始终在柱子上方（核心修改）
        # 计算Y轴最大刻度，预留足够空间放置顶部标签
        max_duration = max(durations) if durations else 0
        plt.ylim(0, max_duration * 1.2)  # 顶部预留20%空间

        # 绘制数值标签（统一在柱子顶部）
        for bar in bars:
            height = bar.get_height()
            # 标签位置固定在柱子顶部上方（距离顶部5%高度处）
            plt.text(
                bar.get_x() + bar.get_width() / 2.,  # X轴居中
                height * 1.05,  # Y轴在柱子顶部上方
                f'{height:.2f}',
                ha='center',
                va='bottom',
                fontsize=9,
                color='black'  # 固定黑色，确保清晰
            )

        # 6. 自动调整布局
        plt.tight_layout()

        # 保存或显示
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"耗时直方图已保存至：{save_path}")
        else:
            plt.show()