# -*- coding: utf-8 -*-
"""
@author: ZYW
"""
import os
import scipy.signal
from matplotlib import pyplot as plt

#######################记录训练和检测过程########################################################################################
class Log():    #参考：github上的yolo3-pytorch-master（202107）
    def __init__(self, path_log, name_dataset, name_model, name_loss_f, name_optimizer):
        import datetime
        curr_time = datetime.datetime.now()
        time_str = datetime.datetime.strftime(curr_time, '%Y_%m_%d_%H_%M_%S')
        self.path_log = path_log
        self.time_str = time_str
        self.path_save = os.path.join(self.path_log, str(self.time_str))
        os.makedirs(self.path_save)

        self.file_config = open(os.path.join(self.path_save,
                                        'log_config__' + name_dataset + '__' + name_model + '__'  + name_loss_f + '__'  + name_optimizer + ".xml"),
                                'a')
        self.file_batch = open(os.path.join(self.path_save,
                                       'log_batch__' + name_dataset + '__' + name_model + '__' + name_loss_f + '__' + name_optimizer + ".csv"),
                               'a')
        self.file_epoch = open(os.path.join(self.path_save,
                                       'log_epoch__' + name_dataset + '__' + name_model + '__' + name_loss_f + '__' + name_optimizer + ".csv"),
                               'a')

    #析构函数
    def __del__(self):
        self.file_config.close()
        self.file_batch.close()
        self.file_epoch.close()

    #记录所有参数设置，含config_GF和config_XX中所有参数，其中XX是某算法（如YOLOv3）。
    #要求：存储到self.file_config文件流中；格式为xml，以方便后续程序调用
    def log_config(self, **kwargs):

        pass

    #每次迭代（批次）后的记录
    #要求：存储到self.file_batch文件流中；格式为csv，其列包括轮序号，批次序号，该批次的训练损失函数值，该批次的验证损失函数值
    def log_batch(self, index_epoch, index_batch, loss_train, loss_val):

        pass

    #每轮后的记录
    #要求：存储到self.file_epoch文件流中；格式为csv，其中列包括轮序号，批次序号，该轮的训练损失函数值，该轮的验证损失函数值
    def log_epoch(self, index_epoch, loss_train, loss_val, time):

        pass


    ##下面的代码是log.py的，要去掉________________________________________________________________________________
    def append_loss(self, loss_train, loss_val):
        self.loss_train.append(loss_train)
        self.loss_val.append(loss_val)
        with open(os.path.join(self.path_save, "epoch_train_loss_" + str(self.time_str) + ".txt"), 'a') as f:
            f.write(str(loss_train))
            f.write("\n")
        with open(os.path.join(self.path_save, "epoch_val_loss_" + str(self.time_str) + ".txt"), 'a') as f:
            f.write(str(loss_val))
            f.write("\n")
        self.loss_plot()

    def loss_plot(self):
        iters = range(len(self.loss_train))

        plt.figure()
        plt.plot(iters, self.loss_train, 'red', linewidth=2, label='train loss')
        plt.plot(iters, self.loss_val, 'coral', linewidth=2, label='val loss')
        try:
            if len(self.loss_train) < 25:
                num = 5
            else:
                num = 15

            plt.plot(iters, scipy.signal.savgol_filter(self.loss_train, num, 3), 'green', linestyle='-', linewidth=2, label='smooth train loss')
            plt.plot(iters, scipy.signal.savgol_filter(self.loss_val, num, 3), '#8B4513', linestyle='--', linewidth=2, label='smooth val loss')
        except:
            pass

        # plt.grid(True)
        plt.xlabel('Epoch')
        plt.ylabel('Loss')
        plt.legend(loc="upper right")

        plt.savefig(os.path.join(self.path_save, "epoch_loss_" + str(self.time_str) + ".png"))

        plt.cla()
        plt.close("all")
    #_________________________________________________________________________________________________