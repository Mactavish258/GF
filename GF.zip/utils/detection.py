import colorsys
import os
from tqdm import tqdm
from PIL import Image
import time

import numpy as np
import torch
import torch.nn as nn
from PIL import ImageDraw, ImageFont
from utils.others import  cvtColor, resize_image, normalize


class Detection():
    def __init__(self, config_GF, about_model, path_images):#参数:模型对象，待检测文件或文件夹的路径
        self.config_GF =config_GF
        self.name_model = about_model[0]
        self.path_class_labels = about_model[1]
        self.path_model_weights = about_model[2]
        self.path_images = path_images

    # ---------------------------------------------------#
    #   检测图片
    # ---------------------------------------------------#
    def detect(self):
        img_names = os.listdir(self.path_images)
        for img_name in tqdm(img_names):
            if img_name.lower().endswith(
                    ('.bmp', '.dib', '.png', '.jpg', '.jpeg', '.pbm', '.pgm', '.ppm', '.tif', '.tiff')):
                path_image = os.path.join(self.path_images, img_name)
                image = Image.open(path_image)


                r_image = yolo.detect_image(image)
                if not os.path.exists(dir_save_path):
                    os.makedirs(dir_save_path)
                r_image.save(os.path.join(dir_save_path, img_name.replace(".jpg", ".png")), quality=95, subsampling=0)