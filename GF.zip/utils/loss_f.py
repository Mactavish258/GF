# -*- coding: utf-8 -*-
"""
@author: ZYW
"""

import sys
import torch

##损失函数########################################################################################################################
##部分损失函数来自与pythorch官方：https://pytorch.org/docs/stable/nn.functional.html?highlight=loss%20functions
def create_loss_f(loss_name, **kwargs):#参数:损失函数名，可变长参数
    if loss_name == 'BCE':#binary_cross_entropy,参数参考：https://pytorch.org/docs/stable/generated/torch.nn.functional.binary_cross_entropy.html#torch.nn.functional.binary_cross_entropy
        #loss_f = torch.nn.functional.binary_cross_entropy(**kwargs)
                #参数为：(input, target, weight=None, size_average=None, reduce=None, reduction='mean'
                #BCE，二分类任务
        return torch.nn.BCELoss(**kwargs)
    if loss_name =='CE': #cross_entropy,参数参考：https://pytorch.org/docs/stable/generated/torch.nn.functional.cross_entropy.html#torch.nn.functional.cross_entropy
        #loss_f = torch.nn.functional.cross_entropy(**kwargs)
                #参数为：(input, target, weight=None, size_average=None, ignore_index=- 100, reduce=None, reduction='mean', label_smoothing=0.0
                #CE,多分类任务
        return torch.nn.CrossEntropyLoss(**kwargs)
    else:
        print('不支持所指定的损失函数%s！'%(loss_name))
        sys.exit()

    return loss_f