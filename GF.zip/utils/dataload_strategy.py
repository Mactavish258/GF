# -*- coding: utf-8 -*-
"""
通用数据集加载策略（修改后：显式传入batch_size，贴合实际逻辑）
"""
import torch
from torch.utils.data import DataLoader
from tqdm import tqdm
from utils.dataset import Dataset


class DataLoadStrategy:
    """通用数据加载策略类"""
    def __init__(self, config_GF):
        self.config_GF = config_GF  # 仅保留全局配置（不含batch_size）

    def get_data_loaders(
        self,
        dataset_class,        # 数据集类
        collate_fn,           # 数据拼接函数
        lines_train,          # 训练集路径列表
        lines_val,            # 验证集路径列表
        input_shape,          # 输入尺寸
        data_augmentation,    # 数据增强开关
        dataset_normalize,    # 标准化配置
        num_train,            # 训练样本数
        num_val,              # 验证样本数
        batch_size            # 新增：显式传入batch_size（核心修改）
    ):
        """获取数据加载器（新增batch_size参数）"""
        # 训练集加载（使用传入的batch_size，替换原config_GF.get(...)）
        if self.config_GF['load_to_memory']:
            dataset_train = self._create_memory_dataset(
                dataset=dataset_class(
                    lines_train,
                    input_shape,
                    data_augmentation,
                    dataset_normalize
                ),
                num_samples=num_train
            )
            data_loader_train = DataLoader(
                dataset_train,
                shuffle=True,
                batch_size=batch_size,  # 直接使用传入的batch_size（核心修改）
                num_workers=0,
                pin_memory=True,
                drop_last=True,
                collate_fn=collate_fn
            )
        else:
            dataset_train = dataset_class(
                lines_train,
                input_shape,
                data_augmentation,
                dataset_normalize
            )
            data_loader_train = DataLoader(
                dataset_train,
                shuffle=True,
                batch_size=batch_size,  # 直接使用传入的batch_size（核心修改）
                num_workers=self.config_GF['num_works'],
                pin_memory=False,
                drop_last=True,
                collate_fn=collate_fn
            )

        # 验证集加载（同样使用传入的batch_size）
        if self.config_GF['load_to_memory']:
            dataset_val = self._create_memory_dataset(
                dataset=dataset_class(
                    lines_val,
                    input_shape,
                    False,
                    dataset_normalize
                ),
                num_samples=num_val
            )
            data_loader_val = DataLoader(
                dataset_val,
                shuffle=False,
                batch_size=batch_size,  # 直接使用传入的batch_size（核心修改）
                num_workers=0,
                pin_memory=True,
                drop_last=True,
                collate_fn=collate_fn
            )
        else:
            dataset_val = dataset_class(
                lines_val,
                input_shape,
                False,
                dataset_normalize
            )
            data_loader_val = DataLoader(
                dataset_val,
                shuffle=False,
                batch_size=batch_size,  # 直接使用传入的batch_size（核心修改）
                num_workers=self.config_GF['num_works'],
                pin_memory=False,
                drop_last=True,
                collate_fn=collate_fn
            )

        return data_loader_train, data_loader_val

    # 以下方法完全不变（缓存逻辑无需修改）
    def _create_memory_dataset(self, dataset, num_samples):
        images = []
        labels = []
        for i in tqdm(range(num_samples), desc="缓存数据到内存"):
            img, label = dataset[i]
            images.append(img)
            labels.append(label)

        class InlineMemoryDataset(Dataset):
            def __init__(self, imgs, lbls):
                self.images = imgs
                self.labels = lbls

            def __len__(self):
                return len(self.images)

            def __getitem__(self, index):
                return self.images[index], self.labels[index]

        return InlineMemoryDataset(images, labels)