# -*- coding: utf-8 -*-
"""
此算法总结自：https://github.com/bubbliiiing/yolo3-pytorch（202107、202203）
@author: ZYW
"""
from torch.utils.data import DataLoader
from PIL import ImageFont, ImageDraw
import colorsys

from .nets.yolo3 import YoloBody
from .nets.yolo_training import YOLOLoss
from .utils.dataloader import YoloDataset, yolo_dataset_collate
from .utils.decode_box import DecodeBox
import torch.backends.cudnn as cudnn
import numpy as np
import os

from utils.dataset import *
from utils.loss_f import *
from utils.optimizer import *
from utils.others import *

##专用参数配置###########################################################################
config_YOLOv3 = {
        ######训练和预测时都需要的参数
        # 先验框的路径，例如：./algs/YOLOv3/model_data/yolo_anchors.txt
        'anchors': os.path.join('algs', 'YOLOv3', 'model_data', 'yolo_anchors.txt'), \

        ######训练时的参数                            freeze是冻结阶段的
        #学习率
        'lr_freeze':1e-3,\
        'lr_unfreeze':1e-3,\
        #学习率衰减因子
        'lr_gamma':0.92,\
        #批次大小
        'batch_size_freeze':4,\
        'batch_size_unfreeze':4,\
        # epoch的数量。如果不冻结，则把'epochs_freeze'设置为0
        'epoch_index_end_freeze': 2, \
        'epoch_index_end_unfreeze': 4, \
        # #是否对损失进行归一化，用于改变loss的大小,用于决定计算最终loss是除上batch_size还是除上正样本数量
        # 'normalize' : False,\
        }

class Alg_YOLOv3():
    def __init__(self, is_train, config_GF, **kwargs):#参数:
        self.is_train = is_train
        self.config_GF = config_GF
        self.anchors = get_anchors(config_YOLOv3['anchors'])     #读取 YOLOv3 模型的 anchor 配置，并转为模型能用的格式，作为先验框用于目标检测预测。

        ##Alg可以处于训练和预测两状态之一，各状态要作不同的处理
        if is_train:    #训练时
            #检查参数配置
            if config_YOLOv3['epoch_index_end_freeze'] >= config_YOLOv3['epoch_index_end_unfreeze']:
                print('因所设置的epoch序号不正确而无法进入解冻阶段，导致无法构造模型！')
                sys.exit()
            if config_GF['dataset_normalize']['is']:
                print('  虽然设置了对图像作标准化处理，但YOLOv3 暂未按此处理（因为该功能尚未验证）！')

            self.dataset = kwargs['dataset']
            self.num_classes = self.dataset.num_classes

            # 损失函数待确定
            self.loss_f = False

            # 优化器待确定
            self.optimizer = False
            self.lr_scheduler = False

            # 标识是否处于冻结状态
            self.flag_freeze = True
        else:   #预测时
            self.path_model_weights = kwargs['path_model_weights']
            self.class_labels = get_class_label(kwargs['path_class_labels'])
            self.num_classes = len(self.class_labels)

            #预测框解码器待定
            self.decode_box = DecodeBox(self.anchors, self.num_classes, self.config_GF['input_shape'])  #解码网络输出为实际框（坐标、类别、置信度，DecodeBox 是一个工具类，用于处理 YOLO 输出的预测张量

            #设置标签字体和预测框线粗
            self.font = ImageFont.truetype(font=self.config_GF['save_box_label']['font'],
                                      size=self.config_GF['save_box_label']['font_size'])  # 设置字体
            self.thickness = self.config_GF['save_box_label']['thickness']  # 设置边框线粗
            #设置预测框不同的颜色
            hsv_tuples = [(x / self.num_classes, 1., 1.) for x in range(self.num_classes)]
            self.colors = list(map(lambda x: colorsys.hsv_to_rgb(*x), hsv_tuples))
            self.colors = list(map(lambda x: (int(x[0] * 255), int(x[1] * 255), int(x[2] * 255)), self.colors))

        # 网络模型待确定
        self.model = False




    ##构造网络模型#########################################################################
    def set_model(self):
        model= YoloBody(self.anchors, self.num_classes)

        if self.is_train:
            # for parameters in model.parameters():   #查看模型参数
            #     print(parameters)
            if self.config_GF['pretrained']:
                path_model_weights = os.path.join(self.config_GF['path_pretrained_model_weights'], self.dataset.name_dataset+'_YOLOv3.pth')
                # model.backbone.load_state_dict(torch.load(path_model_weights))
                load_model_weights(model, path_model_weights, self.config_GF['cuda'])

                # for parameters in model.parameters():
                #     # print(parameters)
                #
                #     if np.isnan(parameters.detach().numpy()).any():
                #         print('nan')
            else:
                init_weights(model)  # 按照自己的策略初始化权重，虽然前面Pytorch本来已有初始化
        else:
            load_model_weights(model, self.path_model_weights, self.config_GF['cuda'])

        if self.config_GF['cuda']:  # 采用CUDA
            # model = torch.nn.DataParallel(model)  # 可优化：https://zhuanlan.zhihu.com/p/206467852
                                            # torch.nn.DataParallel： https://zhuanlan.zhihu.com/p/102697821
                                            # torch.nn.parallel.DistributedDataParallel： https://zhuanlan.zhihu.com/p/467103734
            cudnn.benchmark = True  # 优化卷积计算方式。参考：https://zhuanlan.zhihu.com/p/73711222
            model.cuda()  # 模型迁移到显存中去。X.cpu()将X从显存迁移到内存。

        self.model = model
    #__________________________________________________________________________________________


    ##构造损失函数##########################################################################
    def set_loss_f( self, name_loss_f):
        if not self.is_train:
            print('当前算法处于预测状态，无法设置损失函数.' + warning[0])
            sys.exit()

        if  name_loss_f in ['default']:                                             #使用yolo默认的损失函数
            num_classes = self.dataset.num_classes
            self.loss_f = YOLOLoss(np.reshape(self.anchors,[-1,2]), num_classes, self.config_GF['input_shape'],
                                     self.config_GF['cuda'])
        else:
            # self.loss_f = create_loss_f(self.config_GF, **kwargs)
            print('YOLOv3暂不支持所设置的损失函数.' + warning[0])
            sys.exit()
    #__________________________________________________________________________________________


    ##构造优化器##########################################################################
    def set_optimizer(self, name_optimizer):
        if not self.is_train:
            print('当前算法处于预测状态，无法设置损失函数.' + warning[0])
            sys.exit()

        if name_optimizer in ['Adam']:
            if self.flag_freeze:
                lr = config_YOLOv3['lr_freeze']
            else:
                lr = config_YOLOv3['lr_unfreeze']

            optimizer = create_optimizer(name_optimizer, self.model, lr=lr)
            #等价于optimizer = torch.optim.Adam(filter(lambda p: p.requires_grad, model.parameters()), lr=lr)
            self.optimizer = optimizer
            self.lr_scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=1, gamma=config_YOLOv3['lr_gamma'])   #按固定步长(epoch)降低学习率的调度器,*lr_gamma
        elif name_optimizer == 'PSO':
            optimizer = create_optimizer(name_optimizer, self.model, self.loss_f)

            self.optimizer = optimizer
        else:
            print('YOLOv3暂不支持所设置的优化器.' + warning[0])
            sys.exit()
    #__________________________________________________________________________________________


    ##训练网络#############################################################################################################################################################
    def train(self,log):
        if not self.is_train:
            print('当前算法处于预测状态，无法训练网络.' + warning[0])
            sys.exit()

        ##########准备数据集###########################
        ##分割训练数据集和验证数据集
        with open(self.dataset.get_path_train()) as f:  #f由于是在with中，会在with后面的代码块全部被执行完毕后，自动关闭
            lines_train = f.readlines()
        with open(self.dataset.get_path_val()) as f:
            lines_val = f.readlines()

        num_train = self.dataset.num_train
        num_val = self.dataset.num_val

        ##构造数据集加载器
        dataset_train = YoloDataset(lines_train, (self.config_GF['input_shape'][0], self.config_GF['input_shape'][1]), self.config_GF['data_augmentation'], self.config_GF['dataset_normalize'])
        dataset_val = YoloDataset(lines_val, (self.config_GF['input_shape'][0], self.config_GF['input_shape'][1]), False, self.config_GF['dataset_normalize'])


        #############两阶段训练（冻结+解冻）###########################################
        for flag_freeze in [True,False]:
            ##为两个阶段设置不同参数
            for param in self.model.backbone.parameters():  # 冻结主干网络：主干特征提取网络特征通用，冻结训练可以加快训练速度;也可以在训练初期防止权值被破坏
                param.requires_grad = not flag_freeze       # 确立哪些参数是可训练的
            if flag_freeze == True:    #是冻结状态
                batch_size = config_YOLOv3['batch_size_freeze']
                epoch_index_start = 0
                epoch_index_end = config_YOLOv3['epoch_index_end_freeze']
                print('  冻结阶段的训练:')
            else:   #解冻状态
                batch_size = config_YOLOv3['batch_size_unfreeze']
                epoch_index_start = config_YOLOv3['epoch_index_end_freeze']
                epoch_index_end = config_YOLOv3['epoch_index_end_unfreeze']
                print('  解冻阶段的训练:')

            ##判断每一轮的大小，即每一轮的批次数
            epoch_size_train = num_train // batch_size
            epoch_size_val = num_val // batch_size
            if epoch_size_train == 0 or epoch_size_val == 0:
                raise ValueError("数据集过小，无法进行训练，请扩充数据集.")

            # 重新设置优化器
            if flag_freeze == False:
                self.flag_freeze = flag_freeze
                self.set_optimizer('Adam')             #重新创建了包含当前所有可训练参数的新优化器

            ##数据分批  （这不是自己写的API）
            data_loader_train = DataLoader(dataset_train, shuffle=False, batch_size=batch_size, num_workers=self.config_GF['num_works'], pin_memory=False,
                                   drop_last=True, collate_fn=yolo_dataset_collate)
            data_loader_val = DataLoader(dataset_val, shuffle=True, batch_size=batch_size, num_workers=self.config_GF['num_works'], pin_memory=False,
                                 drop_last=True, collate_fn=yolo_dataset_collate)

            ##迭代训练
            if epoch_index_start == epoch_index_end:
                print('    没有冻结阶段！') if self.flag_freeze else print('    没有解冻阶段！')
            for epoch_index in range(epoch_index_start, epoch_index_end):
                train_in_one_epoch(data_loader_train, data_loader_val, self.model, self.loss_f, self.optimizer, self.config_GF['cuda'], epoch_index, epoch_index_end, epoch_size_train, epoch_size_val, log)
                self.lr_scheduler.step()

    #__________________________________________________________________________________________


    ##目标检测#############################################################################################################################################################
    def detect(self, path_image, log):
        if self.is_train:
            print('当前算法处于训练状态，无法作目标检测。' + warning[0])
            sys.exit()

        img_names = os.listdir(path_image)
        for img_name in tqdm(img_names):
            if img_name.lower().endswith(
                    ('.bmp', '.dib', '.png', '.jpg', '.jpeg', '.pbm', '.pgm', '.ppm', '.tif', '.tiff')):
                image_path = os.path.join(path_image, img_name)
                image = Image.open(image_path)
                image_shape = np.array(np.shape(image)[0:2])
                # ---------------------------------------------------------#
                #   在这里将图像转换成RGB图像，防止灰度图在预测时报错。
                #   代码仅仅支持RGB图像的预测，所有其它类型的图像都会转化成RGB
                # ---------------------------------------------------------#
                image = cvtColor(image)
                # ---------------------------------------------------------#
                #   给图像增加灰条，实现不失真的resize
                #   也可以直接resize进行识别
                # ---------------------------------------------------------#
                image_data = resize_image(image, (self.config_GF['input_shape'][1], self.config_GF['input_shape'][0]), self.config_GF['gray_bar'])
                # ---------------------------------------------------------#
                #   图像归一化，并添加上batch_size维度
                # ---------------------------------------------------------#
                image_data = np.expand_dims(np.transpose(normalize(np.array(image_data, dtype='float32')), (2, 0, 1)), 0)

                self.model.eval()
                with torch.no_grad():
                    images = torch.from_numpy(image_data)
                    if self.config_GF['cuda']:
                        images = images.cuda()
                    # ---------------------------------------------------------#
                    #   将图像输入网络当中进行预测！
                    # ---------------------------------------------------------#
                    outputs = self.model(images)
                    # for parameters in self.model.parameters():   #查看模型参数
                    #     print(parameters)
                    outputs = self.decode_box.decode_box(outputs)
                    # ---------------------------------------------------------#
                    #   将预测框进行堆叠，然后进行非极大抑制
                    # ---------------------------------------------------------#
                    results = self.decode_box.non_max_suppression(torch.cat(outputs, 1), self.num_classes, self.config_GF['input_shape'],
                                                                 image_shape, self.config_GF['gray_bar'], thres_conf=self.config_GF['thres_conf'],
                                                                 thres_iou=self.config_GF['thres_iou'])
                    if results[0] is None:
                        continue    #return image

                    top_label = np.array(results[0][:, 6], dtype='int32')
                    top_conf = results[0][:, 4] * results[0][:, 5]
                    top_boxes = results[0][:, :4]

                # ---------------------------------------------------------#
                #   是否进行目标的裁剪和保存
                # ---------------------------------------------------------#
                if self.config_GF['crop']['is']:
                    path_save = os.path.join(self.config_GF['crop']['path'], "crop_" + os.path.splitext(img_name)[0] + '_')
                    for i, c in list(enumerate(top_label)):
                        predicted_class = self.class_labels[int(c)]
                        score = top_conf[i]

                        top, left, bottom, right = top_boxes[i]
                        top = max(0, np.floor(top).astype('int32'))
                        left = max(0, np.floor(left).astype('int32'))
                        bottom = min(image.size[1], np.floor(bottom).astype('int32'))
                        right = min(image.size[0], np.floor(right).astype('int32'))

                        if not os.path.exists(path_save):
                            os.makedirs(path_save)
                        crop_image = image.crop([left, top, right, bottom])
                        crop_image.save(path_save + str(i) + '_' + predicted_class+ ".png",
                                        quality=95, subsampling=0)
                        print(i)
                # ---------------------------------------------------------#
                #   图像绘制和保存
                # ---------------------------------------------------------#
                if self.config_GF['save_box_label']['is']:
                    for i, c in list(enumerate(top_label)):
                        predicted_class = self.class_labels[int(c)]
                        score = top_conf[i]

                        top, left, bottom, right = top_boxes[i]
                        top = max(0, np.floor(top).astype('int32'))
                        left = max(0, np.floor(left).astype('int32'))
                        bottom = min(image.size[1], np.floor(bottom).astype('int32'))
                        right = min(image.size[0], np.floor(right).astype('int32'))

                        label = '{} {:.2f}'.format(predicted_class, score)
                        draw = ImageDraw.Draw(image)
                        label_size = draw.textsize(label, self.font)
                        label = label.encode('utf-8')
                        print(label, top, left, bottom, right)

                        if top - label_size[1] >= 0:
                            text_origin = np.array([left, top - label_size[1]])
                        else:
                            text_origin = np.array([left, top + 1])

                        for i in range(self.thickness):
                            draw.rectangle([left + i, top + i, right - i, bottom - i], outline=self.colors[c])
                        draw.rectangle([tuple(text_origin), tuple(text_origin + label_size)], fill=self.colors[c])
                        draw.text(text_origin, str(label, 'UTF-8'), fill=(0, 0, 0), font=self.font)

                    #保存带检测框和标签的图像
                    path_save = self.config_GF['save_box_label']['path']
                    if not os.path.exists(path_save):
                        os.makedirs(path_save)
                    image.save(os.path.join(path_save,'box_label_'+os.path.splitext(img_name)[0]+'.png'), quality=95, subsampling=0)

                    del draw

                # return image
    #__________________________________________________________________________________________


##训练一轮#######################################################################################################################
def train_in_one_epoch(data_loader_train, data_loader_val, model, loss_f, optimizer, cuda,      #这他妈是训练一次，不是第一次训练
                  epoch_index, epoch_index_end, epoch_size_train, epoch_size_val, log):
    loss_train = 0
    loss_val = 0

    print(f'    当前轮/总轮数： {epoch_index + 1}/{epoch_index_end}')
    model.train()   #设置model中的training属性为True（model的一成员变量），旨在启动BN和dropout
    with tqdm(total=epoch_size_train, desc='      训练', postfix=dict, mininterval=0.3, ncols=200) as pbar:   #创建进度条
        for iteration, batch in enumerate(data_loader_train):
            if iteration >= epoch_size_train:              #保险机制，可以设置只训练前多少批次
                break

            images, targets = batch[0], batch[1]
            with torch.no_grad():   #torch.no_grad() 是一个上下文管理器，被其包住的代码,不用跟踪反向梯度计算
                if cuda:
                    images = torch.from_numpy(images).type(torch.FloatTensor).cuda()       #将 numpy 数组转为 FloatTensor，并移动到 GPU
                else:
                    images = torch.from_numpy(images).type(torch.FloatTensor)
                targets = [torch.from_numpy(ann).type(torch.FloatTensor) for ann in targets]   #targets 是一个列表（每张图一个标注），也都转为张量格式

            ##前向传播
            optimizer.zero_grad()  # 清零梯度
            outputs = model(images)  # 前向传播
            # assert not torch.any(torch.isnan(images)) #检测images中是否有nan。参考：https://www.zhihu.com/question/49346370/answer/2295237184

            ##计算损失
            losses = []
            num_pos_all = 0
            for l in range(len(outputs)):                            #这里是计算每层的平均损失
                loss_item, num_pos = loss_f(outputs[l], targets)
                losses.append(loss_item)
                num_pos_all += num_pos
            loss = sum(losses) / num_pos_all

            ##反向传播优化
            # with torch.autograd.detect_anomaly(): #判断反向传播是有否nan。参考：https://www.zhihu.com/question/49346370/answer/2295237184
            #     losses.backward()
            loss.backward()     #反向传播
            optimizer.step()    #优化更新参数

            loss_train += loss.item()
            pbar.set_postfix({'当前轮中：学习率': get_lr(optimizer),
                              '平均每批的训练损失值': loss_train / (iteration + 1),
                              '最近一批的训练损失值': loss.item(),
                                })
            pbar.update(1)

    model.eval()
    with tqdm(total=epoch_size_val, desc='      验证', postfix=dict, mininterval=0.3, ncols=200) as pbar:
        for batch_index, batch in enumerate(data_loader_val):
            if batch_index >= epoch_size_val:
                break
            images, targets = batch[0], batch[1]

            with torch.no_grad():
                if cuda:
                    images = torch.from_numpy(images).type(torch.FloatTensor).cuda()
                else:
                    images = torch.from_numpy(images).type(torch.FloatTensor)
                targets = [torch.from_numpy(ann).type(torch.FloatTensor) for ann in targets]

                ##前向传播
                # optimizer.zero_grad()   #清零梯度
                outputs = model(images) #前向传播
                assert not torch.any(torch.isnan(images))

                ##计算损失
                losses = []
                num_pos_all = 0
                for l in range(len(outputs)):
                    loss_item, num_pos = loss_f(outputs[l], targets)
                    losses.append(loss_item)
                    num_pos_all += num_pos
                loss = sum(losses) / num_pos_all

            loss_val  += loss.item()
            pbar.set_postfix({'当前轮中：平均每批的验证损失值': loss_val / (batch_index + 1),
                              '最近一批的验证损失值': loss.item(),
                                })
            pbar.update(1)       #进度条向前推一格

    log.append_loss(loss_train / (epoch_size_train), loss_val / (epoch_size_val))
    path_save = os.path.join(log.path_save,'Epoch%d-trainMean%.4f-valMean%.4f.pth' % ((epoch_index + 1), loss_train / (epoch_size_train + 1), loss_val / (epoch_size_val + 1)))
    print('      保存该轮模型到:'+path_save)
    torch.save(model.state_dict(), path_save)         #model.state_dict() 模型中所有可学习参数
#________________________________________________________________________________________________________________________________


##上面要用到的一些函数########################################################
# def get_anchors(anchors_path):
#     '''loads the anchors from a file'''
#     with open(anchors_path, encoding='utf-8') as f:
#         anchors = f.readline()
#     anchors = [float(x) for x in anchors.split(',')]
#     anchors = np.array(anchors).reshape(-1, 2)
#     return anchors
def get_anchors(anchors_path):
    with open(anchors_path) as f:
        anchors = f.readline()
    anchors = [float(x) for x in anchors.split(',')]
    return np.array(anchors).reshape([-1, 3, 2])[::-1, :, :]