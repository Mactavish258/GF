# -*- coding: utf-8 -*-
"""
LeNet5图像分类网络实现
基于原YOLOv3代码框架修改，适配分类任务
"""
import time

from torch.utils.data import DataLoader
from PIL import ImageFont, ImageDraw
import colorsys

from .nets.LeNet5 import LeNet5Body
from .utils.dataloader import LeNet5Dataset,lenet5_dataset_collate
import sys
import torch
import torch.nn as nn
import torch.optim as optim
import torch.backends.cudnn as cudnn
import numpy as np
import os
from tqdm import tqdm

from utils.dataset import *
from utils.dataload_strategy import *
from utils.loss_f import *
from utils.optimizer import *
from utils.others import *
from utils.analysis import *

##专用参数配置###########################################################################
config_LeNet5 = {
    # 学习率
    'lr': 1e-3,
    # 学习率衰减因子
    'lr_gamma': 1,
    # 批次大小
    'batch_size': 4500,
    # 训练总轮数
    'epochs': 10,
}

class Alg_LeNet5():
    def __init__(self, is_train, config_GF, **kwargs):
        self.is_train = is_train
        self.config_GF = config_GF

        # 移除锚框相关代码，LeNet5不需要先验框

        ##Alg可以处于训练和预测两状态之一，各状态要作不同的处理
        if is_train:  # 训练时
            # 检查参数配置
            self.dataset = kwargs['dataset']
            self.num_classes = self.dataset.num_classes

            # 损失函数待确定
            self.loss_f = False

            # 优化器待确定
            self.optimizer = False
            self.lr_scheduler = False

        else:  # 预测时
            self.path_model_weights = kwargs['path_model_weights']
            self.class_labels = get_class_label(kwargs['path_class_labels'])
            self.num_classes = len(self.class_labels)

            # 设置标签字体
            self.font = ImageFont.truetype(font=self.config_GF['save_box_label']['font'],
                                           size=self.config_GF['save_box_label']['font_size'])
            self.thickness = self.config_GF['save_box_label']['thickness']
            # 设置类别颜色
            hsv_tuples = [(x / self.num_classes, 1., 1.) for x in range(self.num_classes)]
            self.colors = list(map(lambda x: colorsys.hsv_to_rgb(*x), hsv_tuples))
            self.colors = list(map(lambda x: (int(x[0] * 255), int(x[1] * 255), int(x[2] * 255)), self.colors))

        # 网络模型待确定
        self.model = False

    ##构造网络模型#########################################################################
    def set_model(self):
        # 创建LeNet5模型，默认为RGB输入
        model = LeNet5Body(num_classes=self.num_classes, in_channels=3)

        if self.is_train:
            if self.config_GF['pretrained']:
                path_model_weights = os.path.join(
                    self.config_GF['path_pretrained_model_weights'],
                    self.dataset.name_dataset + '_LeNet5.pth'
                )
                load_model_weights(model, path_model_weights, self.config_GF['cuda'])
            else:
                init_weights(model)
        else:
            load_model_weights(model, self.path_model_weights, self.config_GF['cuda'])

        if self.config_GF['cuda']:
            cudnn.benchmark = True
            model.cuda()

        self.model = model


    ##构造损失函数##########################################################################
    def set_loss_f(self, name_loss_f):
        if not self.is_train:
            print('当前算法处于预测状态，无法设置损失函数.' + warning[0])
            sys.exit()

        if name_loss_f in ['default', 'CE']:
            self.loss_f = create_loss_f('CE', reduction='mean')
        elif name_loss_f == 'BCE':
            # 二分类任务使用BCE
            # 注意：使用BCE时需要确保模型输出经过sigmoid激活
            self.loss_f = create_loss_f('BCE', reduction='mean')
        else:
            print('LeNet5暂不支持所设置的损失函数.' + warning[0])
            sys.exit()

    # __________________________________________________________________________________________

    ##构造优化器##########################################################################
    def set_optimizer(self, name_optimizer):
        if not self.is_train:
            print('当前算法处于预测状态，无法设置优化器.' + warning[0])
            sys.exit()

        if name_optimizer in ['Adam']:
            lr = config_LeNet5['lr']
            optimizer = create_optimizer(name_optimizer, self.model, lr=lr)
            self.optimizer = optimizer
            self.lr_scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=1, gamma=config_LeNet5['lr_gamma'])

        elif name_optimizer == 'PSO':
            optimizer = create_optimizer(name_optimizer, self.model)
            self.optimizer = optimizer

        elif name_optimizer == 'PSO_CUDA':
            optimizer = create_optimizer(name_optimizer, self.model)
            self.optimizer = optimizer

        elif name_optimizer == 'PSO_AC_CUDA':
            batch_per_epoch = self.dataset.num_train // config_LeNet5['batch_size']
            total_steps = config_LeNet5['epochs'] * batch_per_epoch
            optimizer = create_optimizer(
                name_optimizer,
                self.model,
                total_steps=total_steps
            )
            self.optimizer = optimizer

        else:
            print('LeNet5暂不支持所设置的优化器.' + warning[0])
            sys.exit()


    ##训练网络#############################################################################################################################################################
    def train(self, log):
        if not self.is_train:
            print('当前算法处于预测状态，无法训练网络.' + warning[0])
            sys.exit()

        ##########准备数据集###########################
        with open(self.dataset.get_path_train()) as f:
            lines_train = f.readlines()
        with open(self.dataset.get_path_val()) as f:
            lines_val = f.readlines()

        num_train = self.dataset.num_train
        num_val = self.dataset.num_val

        batch_size = config_LeNet5['batch_size']
        epoch_size_train = num_train // batch_size
        epoch_size_val = num_val // batch_size
        if epoch_size_train == 0 or epoch_size_val == 0:
            raise ValueError("数据集过小，无法进行训练，请扩充数据集.")

        load_strategy = DataLoadStrategy(config_GF=self.config_GF)
        # 调用策略类获取数据加载器（传入所有必要参数）
        data_loader_train, data_loader_val = load_strategy.get_data_loaders(
            dataset_class=LeNet5Dataset,
            collate_fn=lenet5_dataset_collate,
            lines_train=lines_train,
            lines_val=lines_val,
            num_train=num_train,
            num_val=num_val,
            input_shape=(self.config_GF['input_shape'][0], self.config_GF['input_shape'][1]),
            data_augmentation=self.config_GF['data_augmentation'],
            dataset_normalize=self.config_GF['dataset_normalize'],
            batch_size=batch_size
        )

        # 初始化计时器（记录当前模型训练的所有阶段耗时）
        timer = TrainTimer()
        hist_save_path = os.path.join(log.path_save, "训练阶段耗时直方图.png")

        ##迭代训练
        for epoch_index in range(config_LeNet5['epochs']):
            train_start = time.time()
            train_in_one_epoch(
                data_loader_train,
                data_loader_val,
                self.model,
                self.loss_f,
                self.optimizer,
                self.config_GF['cuda'],
                epoch_index,
                config_LeNet5['epochs'],
                epoch_size_train,
                epoch_size_val,
                log,
                timer
            )
            if self.optimizer == 'Adam':
                self.lr_scheduler.step()
            train_end = time.time()
            print(f'当前epoch耗时：%.2f秒' % (train_end - train_start))
        timer.plot_histogram(save_path=hist_save_path)
    # __________________________________________________________________________________________

    ##图像分类预测#############################################################################################################################################################
    def predict(self, path_image, log):
        if self.is_train:
            print('当前算法处于训练状态，无法作分类预测。' + warning[0])
            sys.exit()

        img_names = os.listdir(path_image)
        for img_name in tqdm(img_names):
            if img_name.lower().endswith(
                    ('.bmp', '.dib', '.png', '.jpg', '.jpeg', '.pbm', '.pgm', '.ppm', '.tif', '.tiff')):
                image_path = os.path.join(path_image, img_name)
                image = Image.open(image_path)
                #image_shape = np.array(np.shape(image)[0:2])   不需要检测位置
                # 转换为RGB图像
                image = cvtColor(image)
                # 调整图像大小为32x32（LeNet5输入尺寸）
                image_data = resize_image(
                    image,
                    (32, 32),  # LeNet5标准输入尺寸
                    self.config_GF['gray_bar']
                )
                # 图像预处理
                image_data = np.expand_dims(
                    np.transpose(normalize(np.array(image_data, dtype='float32')), (2, 0, 1)),
                    0
                )

                self.model.eval()
                with torch.no_grad():
                    images = torch.from_numpy(image_data)
                    if self.config_GF['cuda']:
                        images = images.cuda()
                    # 前向传播得到分类结果
                    outputs = self.model(images)
                    # 计算概率并取最大类别
                    probabilities = torch.softmax(outputs, dim=1)
                    max_prob, predicted_class_idx = torch.max(probabilities, 1)
                    predicted_class = self.class_labels[predicted_class_idx.item()]
                    confidence = max_prob.item()

                # 在图像上绘制分类结果
                if self.config_GF['save_box_label']['is']:
                    draw = ImageDraw.Draw(image)
                    # 标签内容
                    label = f'{predicted_class} {confidence:.2f}'
                    # 替代textsize：textbbox返回(left, top, right, bottom)，计算宽高
                    bbox = draw.textbbox((0, 0), label, font=self.font)
                    label_size = (bbox[2] - bbox[0], bbox[3] - bbox[1])
                    # 标签位置（左上角）
                    text_origin = np.array([10, 10])  # 固定在左上角

                    # 绘制标签背景
                    draw.rectangle(
                        [tuple(text_origin), tuple(text_origin + label_size)],
                        fill=self.colors[predicted_class_idx.item()]
                    )
                    # 绘制标签文本
                    draw.text(
                        text_origin,
                        label,
                        fill=(0, 0, 0),
                        font=self.font
                    )
                    del draw

                    # 保存带分类结果的图像
                    path_save = self.config_GF['save_box_label']['path']
                    if not os.path.exists(path_save):
                        os.makedirs(path_save)
                    save_path = os.path.join(
                        path_save,
                        f'class_{os.path.splitext(img_name)[0]}.png'
                    )
                    image.save(save_path, quality=95, subsampling=0)


##训练一轮#######################################################################################################################
def train_in_one_epoch(data_loader_train, data_loader_val, model, loss_f, optimizer, cuda,
                  epoch_index, epoch_index_end, epoch_size_train, epoch_size_val, log, timer):
    loss_train = 0.0
    loss_val = 0.0

    # 记录分类准确率（分类任务特有）
    correct_train = 0
    total_train = 0
    correct_val = 0
    total_val = 0

    print(f'    当前轮/总轮数： {epoch_index + 1}/{epoch_index_end}')
    model.train()  # 启用训练模式（BN/Dropout生效）
    with tqdm(total=epoch_size_train, desc='      训练', postfix=dict, mininterval=0.3, ncols=200) as pbar:
        for iteration, batch in enumerate(data_loader_train):
            if iteration >= epoch_size_train:  # 保险机制：限制最大迭代次数
                break

            # 加载数据（分类任务：图像+标签）
            images, labels = batch[0], batch[1]

            timer.start_stage("训练-数据传输至GPU")
            with torch.no_grad():  # 数据转换阶段不跟踪梯度
                if cuda:
                    images = torch.from_numpy(images).type(torch.FloatTensor).cuda()
                    labels = torch.from_numpy(labels).type(torch.LongTensor).cuda()
                else:
                    images = torch.from_numpy(images).type(torch.FloatTensor)
                    labels = torch.from_numpy(labels).type(torch.LongTensor)
            timer.end_stage()


            if isinstance(optimizer, torch.optim.Optimizer):  #原生优化器
                timer.start_stage("训练-前向传播")
                outputs = model(images)
                timer.end_stage()

                timer.start_stage("训练-损失计算")
                loss = loss_f(outputs, labels)
                timer.end_stage()

                timer.start_stage("训练-反向传播")
                optimizer.zero_grad()
                loss.backward()  # 计算梯度
                timer.end_stage()

                timer.start_stage("训练-参数更新")
                optimizer.step()  # Adam参数更新
                timer.end_stage()
            else:
                optimizer.step(images, labels, loss_f, timer)
                timer.start_stage("PSO-前向传播")
                outputs = model(images)
                timer.end_stage()

                # 新增：PSO的损失计算计时
                timer.start_stage("PSO-损失计算")
                loss = loss_f(outputs, labels)
                timer.end_stage()

            # 累加训练损失与准确率（分类任务特有）
            loss_train += loss.item()
            _, predicted = torch.max(outputs.data, 1)
            total_train += labels.size(0)
            correct_train += (predicted == labels).sum().item()

            # 更新进度条信息
            postfix_dict = {
                '平均每批的训练损失值': loss_train / (iteration + 1),
                '最近一批的训练损失值': loss.item(),
                '训练准确率': f'{correct_train / total_train:.4f}'
            }

            # 仅当优化器为Adam时添加学习率信息
            if isinstance(optimizer, torch.optim.Adam):
                postfix_dict['当前轮中：学习率'] = get_lr(optimizer)

            pbar.set_postfix(postfix_dict)
            pbar.update(1)

    # 验证阶段
    model.eval()  # 启用评估模式（BN/Dropout固定）
    with tqdm(total=epoch_size_val, desc='      验证', postfix=dict, mininterval=0.3, ncols=200) as pbar:
        with torch.no_grad():  # 验证阶段不跟踪梯度
            for batch_index, batch in enumerate(data_loader_val):
                if batch_index >= epoch_size_val:
                    break
                #timer.start_stage("验证集数据加载")
                images, labels = batch[0], batch[1]
                #timer.end_stage()

                #timer.start_stage("验证-数据传输至GPU")
                if cuda:
                    images = torch.from_numpy(images).type(torch.FloatTensor).cuda()
                    labels = torch.from_numpy(labels).type(torch.LongTensor).cuda()
                else:
                    images = torch.from_numpy(images).type(torch.FloatTensor)
                    labels = torch.from_numpy(labels).type(torch.LongTensor)
                #timer.end_stage()

                #timer.start_stage("验证-前向传播")
                outputs = model(images)
                #timer.end_stage()

                #timer.start_stage("验证-损失计算")
                loss = loss_f(outputs, labels)
                #timer.end_stage()

                # 累加验证损失与准确率
                loss_val += loss.item()
                _, predicted = torch.max(outputs.data, 1)
                total_val += labels.size(0)
                correct_val += (predicted == labels).sum().item()

                # 更新进度条信息
                pbar.set_postfix({
                    '当前轮中：平均每批的验证损失值': loss_val / (batch_index + 1),
                    '最近一批的验证损失值': loss.item(),
                    '验证准确率': f'{correct_val / total_val:.4f}'
                })
                pbar.update(1)

    # 计算平均损失与准确率
    avg_loss_train = loss_train / epoch_size_train
    avg_loss_val = loss_val / epoch_size_val
    acc_train = correct_train / total_train
    acc_val = correct_val / total_val

    # 记录日志
    log.append_loss(avg_loss_train, avg_loss_val)
    log.append_accuracies({'acc_train': acc_train, 'acc_val': acc_val})  # 分类任务补充准确率日志

    # 保存模型
    path_save = os.path.join(
        log.path_save,
        f'Epoch{epoch_index + 1}-trainMean{avg_loss_train:.4f}-valMean{avg_loss_val:.4f}-valAcc{acc_val:.4f}.pth'
    )
    print(f'      保存该轮模型到: {path_save}')
    torch.save(model.state_dict(), path_save)
# ________________________________________________________________________________________________________________________________
