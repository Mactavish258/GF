import torch.nn as nn
from collections import OrderedDict


def conv2d(filter_in, filter_out, kernel_size, stride=1, padding=0):
    """创建卷积+ReLU模块"""
    return nn.Sequential(OrderedDict([
        ("conv", nn.Conv2d(filter_in, filter_out, kernel_size=kernel_size,
                           stride=stride, padding=padding, bias=False)),
        ("relu", nn.ReLU(inplace=True)),
    ]))


class LeNet5(nn.Module):
    """LeNet5网络结构实现"""

    def __init__(self, num_classes=10, in_channels=3):
        super(LeNet5, self).__init__()
        # 特征提取部分
        self.features = nn.Sequential(
            # C1: 卷积层 (in_channels)x32x32 -> 6x28x28
            conv2d(in_channels, 6, kernel_size=5),
            # S2: 平均池化层 6x28x28 -> 6x14x14
            nn.AvgPool2d(kernel_size=2, stride=2),
            # C3: 卷积层 6x14x14 -> 16x10x10
            conv2d(6, 16, kernel_size=5),
            # S4: 平均池化层 16x10x10 -> 16x5x5
            nn.AvgPool2d(kernel_size=2, stride=2),
            # C5: 卷积层 16x5x5 -> 120x1x1 (全连接)
            conv2d(16, 120, kernel_size=5),
        )

        # 分类部分
        self.classifier = nn.Sequential(
            # F6: 全连接层 120 -> 84
            nn.Linear(120, 84),
            nn.ReLU(inplace=True),
            # F7: 输出层 84 -> num_classes
            nn.Linear(84, num_classes),
        )

    def forward(self, x):
        x = self.features(x)
        # 将特征图展平为一维向量
        x = x.view(x.size(0), -1)
        x = self.classifier(x)
        return x


def LeNet5Body(num_classes=10, in_channels=3):
    """创建LeNet5网络实例"""
    return LeNet5(num_classes, in_channels)